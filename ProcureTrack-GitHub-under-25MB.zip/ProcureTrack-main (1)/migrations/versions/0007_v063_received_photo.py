"""Store a delivery photo on each received ticket.

Revision ID: 0007_v063_received_photo
Revises: 0006_v062_requisition_items
Create Date: 2026-10-13
"""

import sqlalchemy as sa
from alembic import op

revision = "0007_v063_received_photo"
down_revision = "0006_v062_requisition_items"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("procurement_requests") as batch:
        batch.add_column(sa.Column("received_photo", sa.String(length=255), nullable=True))


def downgrade():
    raise RuntimeError(
        "Downgrading is not supported. Restore the pre-migration backup from the "
        "data folder's backups/ directory instead."
    )
