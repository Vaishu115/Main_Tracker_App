"""Persist requests while they wait for Team Lead approval.

Revision ID: 0008_team_lead_requests
Revises: 0007_v063_received_photo
Create Date: 2026-10-13
"""

import sqlalchemy as sa
from alembic import op

revision = "0008_team_lead_requests"
down_revision = "0007_v063_received_photo"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "team_lead_requests",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("requester_id", sa.Integer(), nullable=False),
        sa.Column("form_data", sa.JSON(), nullable=False),
        sa.Column("item_data", sa.JSON(), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("decided_at", sa.DateTime(), nullable=True),
        sa.Column("decided_by_id", sa.Integer(), nullable=True),
        sa.Column("decision_comment", sa.String(length=1000), nullable=True),
        sa.Column("ticket_id", sa.String(length=20), nullable=True),
        sa.Column("email_sent_at", sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(["decided_by_id"], ["users.id"]),
        sa.ForeignKeyConstraint(["requester_id"], ["users.id"]),
        sa.PrimaryKeyConstraint("id"),
    )


def downgrade():
    raise RuntimeError(
        "Downgrading is not supported. Restore the pre-migration backup from the "
        "data folder's backups/ directory instead."
    )
