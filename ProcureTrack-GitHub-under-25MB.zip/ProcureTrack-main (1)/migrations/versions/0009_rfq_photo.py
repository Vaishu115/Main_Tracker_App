"""Store an RFQ photo on the procurement ticket.

Revision ID: 0009_rfq_photo
Revises: 0008_team_lead_requests
Create Date: 2026-10-13
"""

import sqlalchemy as sa
from alembic import op

revision = "0009_rfq_photo"
down_revision = "0008_team_lead_requests"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("procurement_requests") as batch:
        batch.add_column(sa.Column("rfq_photo", sa.String(length=255), nullable=True))


def downgrade():
    raise RuntimeError(
        "Downgrading is not supported. Restore the pre-migration backup from the "
        "data folder's backups/ directory instead."
    )
