"""Replace the RFQ photo with a PDF/document attachment.

Revision ID: 0010_rfq_document
Revises: 0009_rfq_photo
Create Date: 2026-10-13
"""

import sqlalchemy as sa
from alembic import op

revision = "0010_rfq_document"
down_revision = "0009_rfq_photo"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("procurement_requests") as batch:
        batch.alter_column(
            "rfq_photo",
            new_column_name="rfq_attachment",
            existing_type=sa.String(length=255),
        )
        batch.add_column(sa.Column("rfq_attachment_name", sa.String(length=255), nullable=True))
    op.execute(
        "UPDATE procurement_requests "
        "SET rfq_attachment_name = rfq_attachment "
        "WHERE rfq_attachment IS NOT NULL"
    )


def downgrade():
    raise RuntimeError(
        "Downgrading is not supported. Restore the pre-migration backup from the "
        "data folder's backups/ directory instead."
    )
