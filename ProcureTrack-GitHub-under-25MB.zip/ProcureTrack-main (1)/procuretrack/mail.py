"""Microsoft Graph mail notifications for approval workflows."""

import html
import json
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

import msal
from flask import current_app


class MailDeliveryError(Exception):
    """A notification could not be sent through Microsoft Graph."""


def send_team_lead_request(team_lead_request, requester, review_url):
    """Send a pending requisition to the configured Team Lead mailbox."""
    config = current_app.config
    tenant = config.get("MS_TENANT_ID")
    client_id = config.get("MS_CLIENT_ID")
    client_secret = config.get("MS_CLIENT_SECRET")
    mailbox = config.get("MS_MAILBOX")
    if not all((tenant, client_id, client_secret, mailbox)):
        raise MailDeliveryError(
            "Microsoft Graph mail is not configured. Ask the admin to set the mail sender."
        )

    application = msal.ConfidentialClientApplication(
        client_id,
        authority=f"https://login.microsoftonline.com/{tenant}",
        client_credential=client_secret,
    )
    token = application.acquire_token_for_client(
        scopes=["https://graph.microsoft.com/.default"]
    )
    access_token = token.get("access_token")
    if not access_token:
        current_app.logger.error("Could not get Graph mail token: %s", token.get("error"))
        raise MailDeliveryError("Microsoft Graph could not authorize the mail sender.")

    data = team_lead_request.form_data
    rows = "".join(
        "<li>"
        + html.escape(f"{row['quantity']} {row['unit']} · {row['description']}")
        + "</li>"
        for row in team_lead_request.item_data
    )
    title = data.get("title") or team_lead_request.item_data[0]["description"]
    message = {
        "subject": f"Team Lead approval requested: {title}",
        "body": {
            "contentType": "HTML",
            "content": (
                "<p>A procurement request is waiting for your approval.</p>"
                f"<p><b>Requested by:</b> {html.escape(requester.name)}"
                f" ({html.escape(requester.email)})<br>"
                f"<b>Owner:</b> {html.escape(data.get('owner') or '')}<br>"
                f"<b>Priority:</b> {html.escape(data.get('priority') or '')}</p>"
                f"<p><b>Items:</b></p><ul>{rows}</ul>"
                f"<p><a href=\"{html.escape(review_url, quote=True)}\">Review and approve or reject</a></p>"
            ),
        },
        "toRecipients": [
            {"emailAddress": {"address": current_app.config["TEAM_LEAD_EMAIL"]}}
        ],
    }
    endpoint = (
        "https://graph.microsoft.com/v1.0/users/"
        f"{quote(mailbox, safe='')}/sendMail"
    )
    request = Request(
        endpoint,
        data=json.dumps({"message": message}).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urlopen(request, timeout=20) as response:
            if response.status != 202:
                raise MailDeliveryError("Microsoft Graph did not accept the approval email.")
    except HTTPError as exc:
        current_app.logger.error("Graph sendMail failed with HTTP %s", exc.code)
        raise MailDeliveryError("Microsoft Graph rejected the approval email.") from exc
    except URLError as exc:
        current_app.logger.error("Graph sendMail could not connect: %s", exc.reason)
        raise MailDeliveryError("Could not connect to Microsoft Graph to send the approval email.") from exc
    except TimeoutError as exc:
        current_app.logger.error("Graph sendMail timed out")
        raise MailDeliveryError("Microsoft Graph timed out while sending the approval email.") from exc
