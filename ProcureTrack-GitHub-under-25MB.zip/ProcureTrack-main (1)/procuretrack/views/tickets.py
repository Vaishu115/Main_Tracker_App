"""
Ticket pages: queue, tracking, archive, the request form, the ticket detail
page and every action on a ticket (advance, approve, hold, edit, ...).

Pattern for each action: load the ticket (404 if missing) -> require()
the permission (403) -> validate the form -> call a function in services.py
-> commit -> flash a message and redirect back to the ticket.
"""

from datetime import datetime
from uuid import uuid4

from flask import (
    Blueprint,
    abort,
    current_app,
    flash,
    g,
    redirect,
    render_template,
    request,
    send_from_directory,
    url_for,
)
from sqlalchemy import or_, select, update
from werkzeug.utils import secure_filename

from .. import purchasing, services
from ..constants import (
    APPROVAL_STAGE,
    EVENT_LABELS,
    FINAL_STAGE,
    FULFILMENT_STATUSES,
    GST_RATES,
    INDIAN_STATES,
    PAYMENT_STATUSES,
    PO_DRAFT,
    PRIORITIES,
    PROCUREMENT_FLOW,
    PROCUREMENT_TYPES,
    STATE_CANCELLED,
    TRACKING_STAGES,
    UNITS,
)
from ..extensions import db
from ..forms import (
    categories_for,
    validate_comment,
    validate_pricing_form,
    validate_request_form,
    validate_tracking_form,
)
from ..mail import MailDeliveryError, send_team_lead_request
from ..models import (
    ROLE_APPROVER,
    ROLE_TEAM_LEAD,
    CompanySettings,
    ProcurementRequest,
    Project,
    PurchaseOrder,
    TeamLeadRequest,
    User,
    Vendor,
)
from ..permissions import approval_role, can, require

bp = Blueprint("tickets", __name__)


def approver_names(ticket):
    """Approvers eligible for this ticket's estimated total."""
    return db.session.scalars(
        select(User.name)
        .where(User.role == approval_role(ticket), User.active.is_(True))
        .order_by(User.name)
    ).all()


def requisition_vendors(ticket=None):
    """Active vendors, plus the ticket's current one even if it was deactivated."""
    current = ticket.recommended_vendor_id if ticket else None
    return db.session.scalars(
        select(Vendor)
        .where(or_(Vendor.active.is_(True), Vendor.id == current))
        .order_by(Vendor.name)
    ).all()


def latest_event(ticket, event_type, new_status=None):
    for event in ticket.history:  # newest first
        if event.event_type == event_type and (
            new_status is None or event.new_status == new_status
        ):
            return event
    return None


def draft_pos():
    """Offered on an approved ticket: 'add to an existing draft PO'."""
    return db.session.scalars(
        select(PurchaseOrder).where(PurchaseOrder.status == PO_DRAFT).order_by(PurchaseOrder.id)
    ).all()


def get_ticket_or_404(ticket_id):
    ticket = db.session.scalar(
        select(ProcurementRequest).where(ProcurementRequest.ticket_id == ticket_id)
    )
    if ticket is None:
        abort(404, description=f"Procurement case {ticket_id} does not exist.")
    return ticket


def item_rows_from_form(form):
    """The item rows as typed, to show the form again after an error."""
    columns = [form.getlist(f"item_{f}") for f in ("id", "description", "quantity", "unit")]
    count = max(len(c) for c in columns)
    rows = []
    for i in range(count):
        values = [c[i] if i < len(c) else "" for c in columns]
        if any(v.strip() for v in values[1:3]):
            rows.append(dict(zip(("id", "description", "quantity", "unit"), values, strict=True)))
    return rows


def render_form(mode, values, errors, item_rows, ticket=None):
    # active projects, plus the ticket's current one even if it has been deactivated
    projects = db.session.scalars(
        select(Project)
        .where(or_(Project.active.is_(True), Project.id == (ticket.project_id if ticket else None)))
        .order_by(Project.name)
    ).all()
    return render_template(
        "ticket_form.html",
        mode=mode,
        ticket=ticket,
        values=values,
        errors=errors,
        item_rows=item_rows or [{"id": "", "description": "", "quantity": "1", "unit": "Nos"}],
        # vendor and items are locked after approval
        edit_items=ticket is None or can("edit_items", ticket),
        vendors=requisition_vendors(ticket),
        states=INDIAN_STATES,
        projects=projects,
        units=UNITS,
        categories=categories_for(ticket),
        procurement_types=PROCUREMENT_TYPES,
        priorities=PRIORITIES,
    ), 400 if errors else 200


def render_detail(ticket, tracking_values=None, tracking_errors=None):
    return render_template(
        "detail.html",
        ticket=ticket,
        flow=PROCUREMENT_FLOW,
        payment_statuses=PAYMENT_STATUSES,
        fulfilment_statuses=FULFILMENT_STATUSES,
        event_labels=EVENT_LABELS,
        approval_stage=APPROVAL_STAGE,
        approvers=approver_names(ticket) if ticket.status == APPROVAL_STAGE else [],
        draft_pos=draft_pos() if ticket.can_be_ordered else [],
        gst_rates=GST_RATES,
        tracking_values=tracking_values,
        tracking_errors=tracking_errors or {},
    ), 400 if tracking_errors else 200


def to_detail(ticket):
    return redirect(url_for("tickets.detail", ticket_id=ticket.ticket_id))


# ---- lists ----


@bp.route("/queue")
def queue():
    tickets = db.session.scalars(
        select(ProcurementRequest)
        .where(ProcurementRequest.archived.is_(False))
        .order_by(ProcurementRequest.id.desc())
    ).all()
    return render_template("queue.html", tickets=tickets)


@bp.route("/tracking")
def tracking():
    tickets = db.session.scalars(
        select(ProcurementRequest)
        .where(
            ProcurementRequest.archived.is_(False),
            ProcurementRequest.state != STATE_CANCELLED,
            ProcurementRequest.status.in_([s for s in TRACKING_STAGES if s != FINAL_STAGE]),
        )
        # soonest delivery first, cases without a date last
        .order_by(
            ProcurementRequest.expected_delivery.is_(None), ProcurementRequest.expected_delivery
        )
    ).all()
    return render_template("tracking.html", tickets=tickets)


@bp.route("/archive")
def archive():
    tickets = db.session.scalars(
        select(ProcurementRequest)
        .where(ProcurementRequest.archived.is_(True))
        .order_by(ProcurementRequest.id.desc())
    ).all()
    return render_template("archive.html", tickets=tickets)


# ---- create / view / edit ----


@bp.route("/request", methods=["GET", "POST"])
def new_request():
    if request.method == "POST":
        data, items, errors = validate_request_form(request.form)
        if errors:
            return render_form("create", request.form, errors, item_rows_from_form(request.form))
        if request.form.get("team_lead_required") == "yes":
            pending = TeamLeadRequest(
                requester_id=g.user.id,
                form_data=data,
                item_data=items,
            )
            db.session.add(pending)
            db.session.commit()
            review_url = url_for(
                "tickets.team_lead_request_detail", request_id=pending.id, _external=True
            )
            try:
                send_team_lead_request(pending, g.user, review_url)
                pending.email_sent_at = datetime.now()
                db.session.commit()
                flash(
                    "Request sent to Vaishnavi for Team Lead approval. "
                    "The procurement case will be created after approval.",
                    "success",
                )
            except MailDeliveryError as exc:
                current_app.logger.warning(
                    "Team Lead email not sent for pending request %s: %s", pending.id, exc
                )
                flash(
                    f"Request {pending.id} is saved, but the Team Lead email could not be sent. "
                    "Ask the admin to configure Microsoft Graph mail.",
                    "error",
                )
            return redirect(url_for("main.dashboard"))
        ticket = services.create_ticket(data, items, g.user)
        flash(f"{ticket.ticket_id} created.", "success")
        return to_detail(ticket)

    return render_form("create", {"priority": "Normal", "owner": g.user.name}, {}, None)


def require_team_lead_request_access():
    if (
        g.user.role != ROLE_TEAM_LEAD
        or g.user.email.lower() != current_app.config["TEAM_LEAD_EMAIL"]
    ):
        abort(403)


@bp.route("/team-lead-requests/<int:request_id>")
def team_lead_request_detail(request_id):
    require_team_lead_request_access()
    pending = db.get_or_404(TeamLeadRequest, request_id)
    project = db.session.get(Project, pending.form_data.get("project_id"))
    vendor = db.session.get(Vendor, pending.form_data.get("recommended_vendor_id"))
    vendor_name = vendor.name if vendor else pending.form_data.get("new_vendor", {}).get("name")
    return render_template(
        "team_lead_request.html", pending=pending, project=project, vendor_name=vendor_name
    )


@bp.route("/team-lead-requests/<int:request_id>/approve", methods=["POST"])
def approve_team_lead_request(request_id):
    require_team_lead_request_access()
    pending = db.get_or_404(TeamLeadRequest, request_id)
    if pending.status != "pending":
        flash("This request has already been decided.", "info")
        return redirect(url_for("tickets.team_lead_request_detail", request_id=request_id))

    comment, errors = validate_comment(request.form, required=False)
    if errors:
        flash(errors["comment"], "error")
        return redirect(url_for("tickets.team_lead_request_detail", request_id=request_id))

    claimed = db.session.execute(
        update(TeamLeadRequest)
        .where(TeamLeadRequest.id == request_id, TeamLeadRequest.status == "pending")
        .values(
            status="processing",
            decided_by_id=g.user.id,
            decided_at=datetime.now(),
            decision_comment=comment or None,
        )
    )
    db.session.commit()
    if not claimed.rowcount:
        flash("This request has already been decided.", "info")
        return redirect(url_for("tickets.team_lead_request_detail", request_id=request_id))

    data = dict(pending.form_data)
    items = [dict(row) for row in pending.item_data]
    try:
        ticket = services.create_ticket(data, items, pending.requester)
    except Exception:
        db.session.rollback()
        pending = db.get_or_404(TeamLeadRequest, request_id)
        pending.status = "pending"
        pending.decided_by_id = None
        pending.decided_at = None
        pending.decision_comment = None
        db.session.commit()
        current_app.logger.exception("Could not create ticket for Team Lead request %s", request_id)
        flash("The procurement case could not be created. Please try again.", "error")
        return redirect(url_for("tickets.team_lead_request_detail", request_id=request_id))

    pending = db.get_or_404(TeamLeadRequest, request_id)
    pending.status = "approved"
    pending.ticket_id = ticket.ticket_id
    db.session.commit()
    flash(f"Team Lead approved the request. {ticket.ticket_id} was created.", "success")
    return to_detail(ticket)


@bp.route("/team-lead-requests/<int:request_id>/reject", methods=["POST"])
def reject_team_lead_request(request_id):
    require_team_lead_request_access()
    pending = db.get_or_404(TeamLeadRequest, request_id)
    if pending.status != "pending":
        flash("This request has already been decided.", "info")
        return redirect(url_for("tickets.team_lead_request_detail", request_id=request_id))
    reason, errors = validate_comment(request.form, required=True)
    if errors:
        flash(errors["comment"], "error")
        return redirect(url_for("tickets.team_lead_request_detail", request_id=request_id))

    result = db.session.execute(
        update(TeamLeadRequest)
        .where(TeamLeadRequest.id == request_id, TeamLeadRequest.status == "pending")
        .values(
            status="rejected",
            decided_by_id=g.user.id,
            decided_at=datetime.now(),
            decision_comment=reason,
        )
    )
    db.session.commit()
    flash(
        "Request rejected." if result.rowcount else "This request has already been decided.",
        "success" if result.rowcount else "info",
    )
    return redirect(url_for("tickets.team_lead_request_detail", request_id=request_id))


@bp.route("/team-lead-requests/<int:request_id>/resend", methods=["POST"])
def resend_team_lead_request(request_id):
    pending = db.get_or_404(TeamLeadRequest, request_id)
    if pending.requester_id != g.user.id or pending.status != "pending":
        abort(403)
    review_url = url_for(
        "tickets.team_lead_request_detail", request_id=pending.id, _external=True
    )
    try:
        send_team_lead_request(pending, pending.requester, review_url)
        pending.email_sent_at = datetime.now()
        db.session.commit()
        flash("Team Lead approval email sent.", "success")
    except MailDeliveryError as exc:
        current_app.logger.warning(
            "Team Lead email retry failed for request %s: %s", pending.id, exc
        )
        flash("The Team Lead email still could not be sent. Ask the admin to check mail setup.", "error")
    return redirect(url_for("main.dashboard"))


@bp.route("/ticket/<ticket_id>")
def detail(ticket_id):
    return render_detail(get_ticket_or_404(ticket_id))


@bp.route("/ticket/<ticket_id>/edit", methods=["GET", "POST"])
def edit(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("edit", ticket)

    if request.method == "POST":
        with_items = can("edit_items", ticket)
        data, items, errors = validate_request_form(
            request.form, with_requisition=with_items, ticket=ticket
        )
        if with_items and not errors:
            errors = services.check_item_changes(ticket, items)
        if errors:
            return render_form(
                "edit", request.form, errors, item_rows_from_form(request.form), ticket
            )
        changes = services.edit_ticket(ticket, g.user, data, items)
        db.session.commit()
        flash(
            "Changes saved." if changes else "No changes to save.", "success" if changes else "info"
        )
        return to_detail(ticket)

    values = {
        "title": ticket.title or "",
        "project_id": str(ticket.project_id or ""),
        "owner": ticket.owner or "",
        "category": ticket.category,
        "procurement_type": ticket.procurement_type,
        "priority": ticket.priority,
        "required_by": ticket.required_by.isoformat() if ticket.required_by else "",
        "description": ticket.description or "",
        "recommended_vendor_id": str(ticket.recommended_vendor_id or ""),
    }
    rows = [
        {"id": str(i.id), "description": i.description, "quantity": str(i.quantity), "unit": i.unit}
        for i in ticket.items
    ]
    return render_form("edit", values, {}, rows, ticket)


@bp.route("/ticket/<ticket_id>/prices", methods=["POST"])
def update_prices(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("pricing", ticket)
    prices, errors = validate_pricing_form(request.form, ticket)
    if errors:
        flash(" ".join(errors.values()), "error")
        return to_detail(ticket)
    changes = services.update_prices(ticket, g.user, prices)
    db.session.commit()
    flash("Prices saved." if changes else "No changes to save.", "success" if changes else "info")
    return to_detail(ticket)


@bp.route("/ticket/<ticket_id>/requisition/print")
def print_requisition(ticket_id):
    """The Purchase Requisition Form, in ERIC's paper format."""
    ticket = get_ticket_or_404(ticket_id)
    sent = latest_event(ticket, "STATUS_CHANGE", new_status=APPROVAL_STAGE)
    approved = latest_event(ticket, "APPROVED")
    # the requisitioner is the engineer who raised it; tickets from before
    # V0.5 have no creator, so fall back to whoever sent it for approval
    requisitioner = ticket.created_by
    if requisitioner is None and sent and sent.user_id:
        requisitioner = db.session.get(User, sent.user_id)
    return render_template(
        "requisition_print.html",
        ticket=ticket,
        company=CompanySettings.get(),
        # [(item, its most recent earlier PO line)] for items bought before
        last_purchases=[
            (item, line)
            for item in ticket.items
            if (line := purchasing.last_purchase(item)) is not None
        ],
        sent=sent,
        approved=approved,
        requisitioner=requisitioner,
    )


@bp.route("/ticket/<ticket_id>/tracking", methods=["POST"])
def update_tracking(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("tracking", ticket)
    if not ticket.in_tracking:
        flash("Tracking details can be recorded once the PO is released.", "error")
        return to_detail(ticket)

    # vendor / PO number text boxes only for older tickets without real POs
    data, comment, errors = validate_tracking_form(
        request.form, include_vendor_fields=not ticket.po_lines
    )
    if errors:
        return render_detail(ticket, tracking_values=request.form, tracking_errors=errors)

    changes = services.update_tracking(ticket, g.user, data, comment)
    db.session.commit()
    if changes or comment:
        flash("Tracking details saved.", "success")
    else:
        flash("No changes to save.", "info")
    return to_detail(ticket)


@bp.route("/ticket/<ticket_id>/rfq-attachment", methods=["POST"])
def upload_rfq_attachment(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("upload-rfq", ticket)

    photo = request.files.get("rfq_attachment")
    if photo is None or not photo.filename:
        flash("Choose an RFQ document before uploading.", "error")
        return to_detail(ticket)

    extension = photo.filename.rsplit(".", 1)[-1].lower() if "." in photo.filename else ""
    signatures = {
        "pdf": (b"%PDF-", "application/pdf"),
        "doc": (b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1", "application/msword"),
        "xls": (b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1", "application/vnd.ms-excel"),
        "ppt": (
            b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1",
            "application/vnd.ms-powerpoint",
        ),
        "docx": (
            b"PK\x03\x04",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ),
        "xlsx": (
            b"PK\x03\x04",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ),
        "pptx": (
            b"PK\x03\x04",
            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        ),
        "rtf": (b"{\\rtf", "application/rtf"),
    }
    if extension not in signatures:
        flash("Upload a PDF, Word, Excel, PowerPoint, or RTF document.", "error")
        return to_detail(ticket)
    header = photo.stream.read(12)
    photo.stream.seek(0)
    signature, _mimetype = signatures[extension]
    if not header.startswith(signature):
        flash("The selected file does not appear to be a supported document.", "error")
        return to_detail(ticket)

    photo_dir = current_app.config["DATA_DIR"] / "rfq_attachments"
    photo_dir.mkdir(parents=True, exist_ok=True)
    filename = f"{uuid4().hex}.{extension}"
    path = photo_dir / filename
    old_filename = ticket.rfq_attachment
    legacy_path = current_app.config["DATA_DIR"] / "rfq_photos" / old_filename if old_filename else None
    try:
        photo.save(path)
        ticket.rfq_attachment = filename
        ticket.rfq_attachment_name = (secure_filename(photo.filename) or f"RFQ.{extension}")[:255]
        services.log_event(
            ticket, g.user, "RFQ_ATTACHMENT_UPLOADED", "RFQ document uploaded"
        )
        db.session.commit()
    except Exception:
        db.session.rollback()
        path.unlink(missing_ok=True)
        raise

    if old_filename:
        (photo_dir / old_filename).unlink(missing_ok=True)
        if legacy_path:
            legacy_path.unlink(missing_ok=True)
    flash("Document uploaded.", "success")
    return to_detail(ticket)


@bp.route("/ticket/<ticket_id>/rfq-attachment")
def rfq_attachment(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    if not ticket.rfq_attachment:
        abort(404)
    extension = ticket.rfq_attachment.rsplit(".", 1)[-1].lower()
    mimetype = {
        "pdf": "application/pdf",
        "doc": "application/msword",
        "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "xls": "application/vnd.ms-excel",
        "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "ppt": "application/vnd.ms-powerpoint",
        "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "rtf": "application/rtf",
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "png": "image/png",
        "webp": "image/webp",
    }.get(extension)
    if mimetype is None:
        abort(404)
    data_dir = current_app.config["DATA_DIR"]
    attachment_dir = data_dir / "rfq_attachments"
    if not (attachment_dir / ticket.rfq_attachment).is_file():
        # Previous RFQ photos stay available for existing tickets after the upload control changes.
        attachment_dir = data_dir / "rfq_photos"
    return send_from_directory(
        attachment_dir,
        ticket.rfq_attachment,
        mimetype=mimetype,
        as_attachment=True,
        download_name=ticket.rfq_attachment_name or ticket.rfq_attachment,
    )


@bp.route("/ticket/<ticket_id>/received-photo", methods=["POST"])
def upload_received_photo(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("upload-stage-photo", ticket)

    photo = request.files.get("received_photo")
    if photo is None or not photo.filename:
        flash("Choose or take a photo before uploading.", "error")
        return to_detail(ticket)

    extension = photo.filename.rsplit(".", 1)[-1].lower() if "." in photo.filename else ""
    signatures = {
        "jpg": (b"\xff\xd8\xff", "image/jpeg"),
        "jpeg": (b"\xff\xd8\xff", "image/jpeg"),
        "png": (b"\x89PNG\r\n\x1a\n", "image/png"),
        "webp": (b"RIFF", "image/webp"),
    }
    signature = signatures.get(extension)
    header = photo.stream.read(12)
    photo.stream.seek(0)
    if (
        signature is None
        or not header.startswith(signature[0])
        or (extension == "webp" and header[8:12] != b"WEBP")
    ):
        flash("Upload a JPG, PNG, or WebP image.", "error")
        return to_detail(ticket)

    photo_dir = current_app.config["DATA_DIR"] / "received_photos"
    photo_dir.mkdir(parents=True, exist_ok=True)
    filename = f"{uuid4().hex}.{extension}"
    path = photo_dir / filename
    old_filename = ticket.received_photo
    try:
        photo.save(path)
        ticket.received_photo = filename
        services.log_event(ticket, g.user, "PHOTO_UPLOADED", f"Delivery photo uploaded at {ticket.status}")
        db.session.commit()
    except Exception:
        db.session.rollback()
        path.unlink(missing_ok=True)
        raise

    if old_filename:
        (photo_dir / old_filename).unlink(missing_ok=True)
    flash("Delivery photo uploaded.", "success")
    return to_detail(ticket)


@bp.route("/ticket/<ticket_id>/received-photo")
def received_photo(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    if not ticket.received_photo:
        abort(404)
    return send_from_directory(
        current_app.config["DATA_DIR"] / "received_photos",
        ticket.received_photo,
        mimetype={"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "webp": "image/webp"}[
            ticket.received_photo.rsplit(".", 1)[-1].lower()
        ],
    )


# ---- workflow actions ----

# action in URL -> (service function, reason required?, success message)
WORKFLOW_ACTIONS = {
    "advance": (services.advance, False, "Moved to {status}."),
    "send-back": (services.send_back, False, "Sent back to {status}."),
    "hold": (services.hold, True, "Case put on hold."),
    "resume": (services.resume, False, "Case resumed."),
    "cancel": (services.cancel, True, "Case cancelled."),
    "reopen": (services.reopen, True, "Case reopened."),
    "set-stage": (services.set_stage, False, "Moved to {status}."),
}


@bp.route(
    "/ticket/<ticket_id>/<any(advance,'send-back',hold,resume,cancel,reopen,'set-stage'):action>",
    methods=["POST"],
)
def workflow_action(ticket_id, action):
    ticket = get_ticket_or_404(ticket_id)
    require(action, ticket)
    service, reason_required, message = WORKFLOW_ACTIONS[action]
    was_at_approval = ticket.status == APPROVAL_STAGE

    if action == "set-stage":
        try:
            stage_index = int(request.form.get("stage_index", ""))
        except ValueError:
            flash("Choose a valid stage.", "error")
            return to_detail(ticket)
        comment, errors = validate_comment(request.form, required=False)
        if errors:
            flash(errors["comment"], "error")
            return to_detail(ticket)
        try:
            service(ticket, g.user, stage_index, comment)
        except services.WorkflowError as exc:
            db.session.rollback()
            flash(str(exc), "error")
            return to_detail(ticket)
        db.session.commit()
        flash(message.format(status=ticket.status), "success")
        return to_detail(ticket)

    comment, errors = validate_comment(request.form, required=reason_required)
    if errors:
        flash(errors["comment"], "error")
        return to_detail(ticket)

    try:
        service(ticket, g.user, comment)
    except services.WorkflowError as exc:
        db.session.rollback()
        flash(str(exc), "error")
        return to_detail(ticket)

    db.session.commit()
    if was_at_approval and action == "advance":
        message = "Approved. Moved to {status}."
    elif (
        was_at_approval
        and action == "send-back"
        and g.user.role in (ROLE_APPROVER, ROLE_TEAM_LEAD)
    ):
        message = "Rejected. Sent back to {status}."
    flash(message.format(status=ticket.status), "success")
    return to_detail(ticket)


# ---- case management ----


@bp.route("/ticket/<ticket_id>/archive", methods=["POST"])
def archive_ticket(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("archive", ticket)
    services.set_archived(ticket, g.user, True)
    db.session.commit()
    flash(f"{ticket.ticket_id} archived.", "success")
    return redirect(url_for("tickets.queue"))


@bp.route("/ticket/<ticket_id>/restore", methods=["POST"])
def restore_ticket(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("restore", ticket)
    services.set_archived(ticket, g.user, False)
    db.session.commit()
    flash(f"{ticket.ticket_id} restored.", "success")
    return to_detail(ticket)


@bp.route("/ticket/<ticket_id>/delete", methods=["POST"])
def delete_ticket(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("delete", ticket)
    services.delete_ticket(ticket)
    db.session.commit()
    flash(f"{ticket_id} permanently deleted.", "success")
    return redirect(url_for("tickets.queue"))
