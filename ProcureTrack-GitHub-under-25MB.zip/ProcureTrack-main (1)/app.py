"""
===========================================================
ProcureTrack - Procurement Ticketing System

Internal procurement tracking and workflow management tool
for ERIC Robotics.

Run it:
    python app.py                     production server (waitress)
    flask --app app run --debug       development server with auto-reload

The application code lives in the procuretrack/ package.
See README.md for setup, configuration and backups.
===========================================================
"""

import os

from procuretrack import __version__, create_app

app = create_app()

if __name__ == "__main__":
    from waitress import serve

    host = os.environ.get("PROCURETRACK_HOST", "127.0.0.1")
    port = int(os.environ.get("PROCURETRACK_PORT", "5000"))
    print(f"ProcureTrack {__version__} running on http://{host}:{port}  (Ctrl+C to stop)")
    serve(app, host=host, port=port, threads=8)
