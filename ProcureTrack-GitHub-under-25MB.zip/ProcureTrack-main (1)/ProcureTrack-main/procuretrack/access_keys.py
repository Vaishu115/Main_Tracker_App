"""Short-lived Cloudflare Access signing-key cache for the Worker runtime."""

from time import monotonic

_JWKS_CACHE = {}
_CACHE_TTL_SECONDS = 600


def get_access_jwk(team_domain, key_id):
    cached = _JWKS_CACHE.get(team_domain)
    if cached is None:
        return None
    fetched_at, jwks = cached
    if monotonic() - fetched_at >= _CACHE_TTL_SECONDS:
        _JWKS_CACHE.pop(team_domain, None)
        return None
    return next((key for key in jwks.get("keys", []) if key.get("kid") == key_id), None)


def cache_access_jwks(team_domain, jwks):
    _JWKS_CACHE[team_domain] = (monotonic(), jwks)
