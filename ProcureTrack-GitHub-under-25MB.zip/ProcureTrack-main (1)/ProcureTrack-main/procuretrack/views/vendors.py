"""Vendor directory: list/search, add, edit, deactivate, and each vendor's POs."""

from io import BytesIO

from flask import Blueprint, abort, flash, redirect, render_template, request, send_file, url_for
from sqlalchemy import or_, select
from werkzeug.utils import secure_filename

from ..constants import CURRENCIES, INDIA, INDIAN_STATES, PO_ISSUED
from ..extensions import db
from ..forms import validate_vendor_form
from ..models import Vendor, VendorDocument
from ..money import ZERO
from ..permissions import require

bp = Blueprint("vendors", __name__, url_prefix="/vendors")

VENDOR_DOCUMENTS = {
    "pan_document": "pan",
    "gst_certificate": "gst",
    "msme_certificate": "msme",
    "cancelled_cheque": "cancelled-cheque",
}
MAX_VENDOR_DOCUMENT_BYTES = 5 * 1024 * 1024


def read_vendor_documents():
    prepared = []
    total = 0
    for field, kind in VENDOR_DOCUMENTS.items():
        upload = request.files.get(field)
        if not upload or not upload.filename:
            continue
        filename = secure_filename(upload.filename)
        suffix = "." + filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        data = upload.stream.read(MAX_VENDOR_DOCUMENT_BYTES + 1)
        if not filename or not data:
            raise ValueError(f"Choose a valid, non-empty file for {kind.replace('-', ' ')}.")
        if len(data) > MAX_VENDOR_DOCUMENT_BYTES:
            raise ValueError(f"{filename} exceeds the 5 MB limit.")
        if suffix == ".pdf" and data.lstrip()[:5] == b"%PDF-":
            content_type = "application/pdf"
        elif suffix in (".jpg", ".jpeg") and data.startswith(b"\xff\xd8\xff"):
            content_type = "image/jpeg"
        elif suffix == ".png" and data.startswith(b"\x89PNG\r\n\x1a\n"):
            content_type = "image/png"
        else:
            raise ValueError(f"{filename} must be a valid PDF, PNG, or JPG file.")
        total += len(data)
        if total > 10 * 1024 * 1024:
            raise ValueError("Vendor documents cannot total more than 10 MB per save.")
        prepared.append((kind, filename, content_type, data))
    return prepared


def save_vendor_documents(vendor, prepared):
    for kind, filename, content_type, data in prepared:
        document = db.session.scalar(
            select(VendorDocument).where(
                VendorDocument.vendor_id == vendor.id, VendorDocument.kind == kind
            )
        )
        if document is None:
            document = VendorDocument(vendor_id=vendor.id, kind=kind)
            db.session.add(document)
        document.filename = filename
        document.content_type = content_type
        document.size_bytes = len(data)
        document.data = data


def render_form(values, errors, vendor=None):
    return render_template(
        "vendor_form.html",
        vendor=vendor,
        values=values,
        errors=errors,
        states=INDIAN_STATES,
        currencies=CURRENCIES,
    ), 400 if errors else 200


@bp.route("/")
def index():
    q = (request.args.get("q") or "").strip()
    show_inactive = request.args.get("show") == "all"
    query = select(Vendor).order_by(Vendor.name)
    if not show_inactive:
        query = query.where(Vendor.active.is_(True))
    if q:
        like = f"%{q}%"
        query = query.where(
            or_(
                Vendor.name.ilike(like),
                Vendor.city.ilike(like),
                Vendor.gstin.ilike(like),
                Vendor.contact_person.ilike(like),
            )
        )
    vendors = db.session.scalars(query).all()
    return render_template("vendors.html", vendors=vendors, q=q, show_inactive=show_inactive)


@bp.route("/new", methods=["GET", "POST"])
def new():
    require("manage_vendors")
    if request.method == "POST":
        data, errors = validate_vendor_form(request.form)
        try:
            prepared_docs = read_vendor_documents()
        except ValueError as exc:
            errors["documents"] = str(exc)
        if errors:
            return render_form(request.form, errors)
        vendor = Vendor(**data)
        db.session.add(vendor)
        db.session.flush()
        save_vendor_documents(vendor, prepared_docs)
        db.session.commit()
        flash(f"Vendor {vendor.name} added.", "success")
        return redirect(url_for("vendors.detail", vendor_id=vendor.id))
    return render_form({"country": INDIA, "default_currency": "INR"}, {})


@bp.route("/<int:vendor_id>")
def detail(vendor_id):
    vendor = db.get_or_404(Vendor, vendor_id)
    pos = sorted(vendor.purchase_orders, key=lambda po: po.id, reverse=True)
    issued = [po for po in pos if po.status == PO_ISSUED]
    total_inr = sum((po.total_inr for po in issued), ZERO)
    return render_template(
        "vendor_detail.html", vendor=vendor, pos=pos, issued=issued, total_inr=total_inr
    )


@bp.route("/<int:vendor_id>/documents/<kind>")
def download_document(vendor_id, kind):
    vendor = db.get_or_404(Vendor, vendor_id)
    document = db.session.scalar(
        select(VendorDocument).where(
            VendorDocument.vendor_id == vendor.id, VendorDocument.kind == kind
        )
    )
    if document is None or kind not in VENDOR_DOCUMENTS.values():
        abort(404)
    response = send_file(
        BytesIO(document.data),
        mimetype=document.content_type,
        as_attachment=True,
        download_name=document.filename,
        max_age=0,
    )
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


@bp.route("/<int:vendor_id>/edit", methods=["GET", "POST"])
def edit(vendor_id):
    require("manage_vendors")
    vendor = db.get_or_404(Vendor, vendor_id)
    if request.method == "POST":
        data, errors = validate_vendor_form(request.form, existing=vendor)
        try:
            prepared_docs = read_vendor_documents()
        except ValueError as exc:
            errors["documents"] = str(exc)
        if errors:
            return render_form(request.form, errors, vendor)
        for field, value in data.items():
            setattr(vendor, field, value)
        save_vendor_documents(vendor, prepared_docs)
        db.session.commit()
        flash("Vendor updated. Issued POs keep the details they were issued with.", "success")
        return redirect(url_for("vendors.detail", vendor_id=vendor.id))

    values = {
        field: getattr(vendor, field) or ""
        for field in (
            "name contact_person email phone address city state_code country gstin pan "
            "gst_registered payment_terms default_currency notes"
        ).split()
    }
    return render_form(values, {}, vendor)


@bp.route("/<int:vendor_id>/active", methods=["POST"])
def toggle_active(vendor_id):
    require("manage_vendors")
    vendor = db.get_or_404(Vendor, vendor_id)
    vendor.active = not vendor.active
    db.session.commit()
    flash(f"{vendor.name} {'reactivated' if vendor.active else 'deactivated'}.", "success")
    return redirect(url_for("vendors.detail", vendor_id=vendor.id))
