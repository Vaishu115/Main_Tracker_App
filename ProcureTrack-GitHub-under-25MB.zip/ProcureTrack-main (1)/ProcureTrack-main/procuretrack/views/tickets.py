"""
Ticket pages: queue, tracking, archive, the request form, the ticket detail
page and every action on a ticket (advance, approve, hold, edit, ...).

Pattern for each action: load the ticket (404 if missing) -> require()
the permission (403) -> validate the form -> call a function in services.py
-> commit -> flash a message and redirect back to the ticket.
"""

from datetime import date, datetime, timedelta
import hashlib
from io import BytesIO
import secrets
from zipfile import BadZipFile, ZipFile

from flask import (
    Blueprint,
    abort,
    current_app,
    flash,
    g,
    redirect,
    render_template,
    request,
    send_file,
    url_for,
)
from werkzeug.utils import secure_filename
from sqlalchemy import func, or_, select

from .. import purchasing, services
from ..constants import (
    APPROVAL_STAGE,
    APPROVAL_STAGES,
    EVENT_LABELS,
    FINAL_STAGE,
    FULFILMENT_STATUSES,
    GST_RATES,
    INDIAN_STATES,
    PAYMENT_METHODS,
    PO_DRAFT,
    PRIORITIES,
    PROCUREMENT_FLOW,
    PROCUREMENT_TYPES,
    RFQ_STAGE,
    STATE_CANCELLED,
    TRACKING_STAGES,
    UNITS,
)
from ..extensions import db
from ..email_notifications import send_team_lead_approval
from ..forms import (
    categories_for,
    validate_comment,
    validate_payment_form,
    validate_pricing_form,
    validate_request_form,
    validate_tracking_form,
)
from ..models import (
    ROLE_APPROVER,
    ROLE_PR_APPROVER,
    ROLE_PURCHASE,
    ROLE_TEAM_LEAD,
    ROLE_TECHNICAL_APPROVER,
    CompanySettings,
    ProcurementRequest,
    Project,
    PurchaseOrder,
    RequestAttachment,
    RequestPhoto,
    TeamLeadApprovalRequest,
    User,
    UserNotification,
    Vendor,
)
from ..permissions import (
    can,
    department_has_team_lead,
    is_team_lead_for_request,
    require,
    same_department,
)

bp = Blueprint("tickets", __name__)

MAX_ATTACHMENT_BYTES = 10 * 1024 * 1024
PHOTO_TYPES = {
    ".jpg": ("image/jpeg", b"\xff\xd8\xff"),
    ".jpeg": ("image/jpeg", b"\xff\xd8\xff"),
    ".png": ("image/png", b"\x89PNG\r\n\x1a\n"),
    ".webp": ("image/webp", b"RIFF"),
}
ATTACHMENT_TYPES = {
    ".pdf": ("application/pdf", None),
    ".docx": (
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "word/document.xml",
    ),
    ".xlsx": (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "xl/workbook.xml",
    ),
}


def read_attachment_upload(upload):
    """Validate and read a supported document without trusting its browser MIME type."""
    filename = secure_filename(upload.filename or "")
    if not filename:
        raise ValueError("Choose a file with a valid filename.")
    suffix = "." + filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    file_type = ATTACHMENT_TYPES.get(suffix)
    if file_type is None:
        raise ValueError("Only PDF, DOCX, and XLSX files are supported.")

    data = upload.stream.read(MAX_ATTACHMENT_BYTES + 1)
    if not data:
        raise ValueError(f"{filename} is empty.")
    if len(data) > MAX_ATTACHMENT_BYTES:
        raise ValueError(f"{filename} is larger than the 10 MB limit.")

    content_type, required_member = file_type
    if suffix == ".pdf":
        if not data[:1024].lstrip().startswith(b"%PDF-"):
            raise ValueError(f"{filename} does not appear to be a valid PDF.")
    else:
        if not data.startswith(b"PK\x03\x04"):
            raise ValueError(f"{filename} does not appear to be a valid Office document.")
        try:
            with ZipFile(BytesIO(data)) as archive:
                if required_member not in archive.namelist():
                    raise ValueError(f"{filename} is missing its expected document content.")
        except BadZipFile as exc:
            raise ValueError(f"{filename} is not a valid Office document.") from exc

    return filename, content_type, data


def prepare_attachments(uploads):
    prepared = []
    total_size = 0
    for upload in uploads:
        filename, content_type, data = read_attachment_upload(upload)
        total_size += len(data)
        if total_size > MAX_ATTACHMENT_BYTES:
            raise ValueError("The total upload size cannot exceed 10 MB at a time.")
        prepared.append((filename, content_type, data))
    return prepared


def add_attachments(ticket, user, prepared):
    for filename, content_type, data in prepared:
        db.session.add(
            RequestAttachment(
                ticket_id=ticket.id,
                uploaded_by_id=user.id,
                filename=filename,
                content_type=content_type,
                size_bytes=len(data),
                data=data,
            )
        )
        services.log_event(ticket, user, "ATTACHMENT_UPLOADED", comment=filename)
    return len(prepared)


def approver_names(ticket):
    """Names of users assigned to this ticket's current approval stage."""
    role = {
        APPROVAL_STAGE: ROLE_PR_APPROVER,
        "PO Release Pending": ROLE_APPROVER,
    }.get(ticket.status)
    if not role:
        return []
    return db.session.scalars(
        select(User.name)
        .where(User.role == role, User.active.is_(True))
        .order_by(User.name)
    ).all()


def requisition_vendors(ticket=None):
    """Active vendors, plus the ticket's current one even if it was deactivated."""
    current = ticket.recommended_vendor_id if ticket else None
    return db.session.scalars(
        select(Vendor)
        .where(or_(Vendor.active.is_(True), Vendor.id == current))
        .order_by(Vendor.name)
    ).all()


def latest_event(ticket, event_type, new_status=None):
    for event in ticket.history:  # newest first
        if event.event_type == event_type and (
            new_status is None or event.new_status == new_status
        ):
            return event
    return None


def draft_pos():
    """Offered on an approved ticket: 'add to an existing draft PO'."""
    return db.session.scalars(
        select(PurchaseOrder).where(PurchaseOrder.status == PO_DRAFT).order_by(PurchaseOrder.id)
    ).all()


def get_ticket_or_404(ticket_id):
    ticket = db.session.scalar(
        select(ProcurementRequest).where(ProcurementRequest.ticket_id == ticket_id)
    )
    if ticket is None:
        abort(404, description=f"Procurement case {ticket_id} does not exist.")
    return ticket


def item_rows_from_form(form):
    """The item rows as typed, to show the form again after an error."""
    columns = [form.getlist(f"item_{f}") for f in ("id", "description", "quantity", "unit")]
    count = max(len(c) for c in columns)
    rows = []
    for i in range(count):
        values = [c[i] if i < len(c) else "" for c in columns]
        if any(v.strip() for v in values[1:3]):
            rows.append(dict(zip(("id", "description", "quantity", "unit"), values, strict=True)))
    return rows


def render_form(mode, values, errors, item_rows, ticket=None):
    # active projects, plus the ticket's current one even if it has been deactivated
    projects = db.session.scalars(
        select(Project)
        .where(or_(Project.active.is_(True), Project.id == (ticket.project_id if ticket else None)))
        .order_by(Project.name)
    ).all()
    return render_template(
        "ticket_form.html",
        mode=mode,
        ticket=ticket,
        values=values,
        errors=errors,
        item_rows=item_rows or [{"id": "", "description": "", "quantity": "1", "unit": "Nos"}],
        # vendor and items are locked after approval
        edit_items=ticket is None or can("edit_items", ticket),
        vendors=requisition_vendors(ticket),
        states=INDIAN_STATES,
        projects=projects,
        units=UNITS,
        categories=categories_for(ticket),
        procurement_types=PROCUREMENT_TYPES,
        priorities=PRIORITIES,
    ), 400 if errors else 200


def render_detail(
    ticket,
    tracking_values=None,
    tracking_errors=None,
    payment_values=None,
    payment_errors=None,
):
    return render_template(
        "detail.html",
        ticket=ticket,
        flow=PROCUREMENT_FLOW,
        payment_methods=PAYMENT_METHODS,
        fulfilment_statuses=FULFILMENT_STATUSES,
        event_labels=EVENT_LABELS,
        approval_stage=APPROVAL_STAGE,
        approval_stages=APPROVAL_STAGES,
        approvers=approver_names(ticket) if ticket.status in APPROVAL_STAGES else [],
        draft_pos=draft_pos() if ticket.can_be_ordered else [],
        gst_rates=GST_RATES,
        tracking_values=tracking_values,
        tracking_errors=tracking_errors or {},
        payment_values=payment_values or {},
        payment_errors=payment_errors or {},
        today=date.today().isoformat(),
    ), 400 if tracking_errors or payment_errors else 200


def to_detail(ticket):
    return redirect(url_for("tickets.detail", ticket_id=ticket.ticket_id))


# ---- lists ----


@bp.route("/queue")
def queue():
    tickets = db.session.scalars(
        select(ProcurementRequest)
        .where(ProcurementRequest.archived.is_(False))
        .order_by(ProcurementRequest.id.desc())
    ).all()
    return render_template("queue.html", tickets=tickets)


@bp.route("/tracking")
def tracking():
    tickets = db.session.scalars(
        select(ProcurementRequest)
        .where(
            ProcurementRequest.archived.is_(False),
            ProcurementRequest.state != STATE_CANCELLED,
            ProcurementRequest.status.in_([s for s in TRACKING_STAGES if s != FINAL_STAGE]),
        )
        # soonest delivery first, cases without a date last
        .order_by(
            ProcurementRequest.expected_delivery.is_(None), ProcurementRequest.expected_delivery
        )
    ).all()
    return render_template("tracking.html", tickets=tickets)


@bp.route("/archive")
def archive():
    tickets = db.session.scalars(
        select(ProcurementRequest)
        .where(ProcurementRequest.archived.is_(True))
        .order_by(ProcurementRequest.id.desc())
    ).all()
    return render_template("archive.html", tickets=tickets)


# ---- create / view / edit ----


@bp.route("/request", methods=["GET", "POST"])
def new_request():
    if request.method == "POST":
        data, items, errors = validate_request_form(request.form)
        if not can("request_team_lead_approval"):
            data["team_lead_approval"] = False
        if errors:
            return render_form("create", request.form, errors, item_rows_from_form(request.form))
        if data["team_lead_approval"]:
            token = secrets.token_urlsafe(32)
            payload = dict(data)
            if payload["required_by"]:
                payload["required_by"] = payload["required_by"].isoformat()
            approval_request = TeamLeadApprovalRequest(
                token_hash=hashlib.sha256(token.encode()).hexdigest(),
                payload=payload,
                items=[{key: row[key] for key in ("description", "quantity", "unit")} for row in items],
                requester_id=g.user.id,
                expires_at=datetime.now() + timedelta(days=7),
            )
            db.session.add(approval_request)
            db.session.commit()
            lead_names = db.session.scalars(
                select(User.name)
                .where(
                    User.active.is_(True),
                    User.role == ROLE_TEAM_LEAD,
                    func.lower(func.trim(User.department))
                    == (g.user.department or "").strip().casefold(),
                )
                .order_by(User.name)
            ).all()
            lead_label = ", ".join(lead_names) if lead_names else "the Team Lead"
            if send_team_lead_approval(approval_request):
                flash(f"Sent to {lead_label} for Team Lead approval by email.", "success")
            else:
                flash(
                    f"Request saved for {lead_label}. Email could not be sent; it remains available in the Team Lead inbox.",
                    "warning",
                )
            return redirect(url_for("main.dashboard"))
        ticket = services.create_ticket(data, items, g.user)
        flash(f"{ticket.ticket_id} created. No Team Lead approval was requested.", "success")
        return to_detail(ticket)

    return render_form(
        "create",
        {"priority": "Normal", "owner": g.user.name, "team_lead_approval": "no"},
        {},
        None,
    )


def get_team_lead_request_or_404(token):
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    approval_request = db.session.scalar(
        select(TeamLeadApprovalRequest)
        .where(TeamLeadApprovalRequest.token_hash == token_hash)
        .with_for_update()
    )
    if approval_request is None:
        abort(404)
    return approval_request


def requester_is_engineering(approval_request):
    requester = approval_request.requester
    if requester is None:
        return False
    engineering_indicators = (
        requester.department,
        requester.name,
        approval_request.payload.get("owner"),
        (requester.email or "").split("@", 1)[0],
    )
    department = (requester.department or "").strip().casefold()
    return department in {"electronics", "engineering"} or any(
        (value or "").strip().casefold().startswith("engineering")
        for value in engineering_indicators
    )


def create_ticket_from_team_lead_approval(approval_request):
    if approval_request.decision != "approved" or approval_request.ticket_id:
        abort(409, description="This approved request has already been processed.")
    requester = db.session.get(User, approval_request.requester_id)
    if requester is None or not requester.active:
        db.session.rollback()
        abort(409, description="The requester account is unavailable; contact the admin.")
    if not department_has_team_lead(requester.department):
        abort(409, description="The requester's department no longer has an active Team Lead.")
    data = dict(approval_request.payload)
    if data.get("required_by"):
        data["required_by"] = date.fromisoformat(data["required_by"])
    data["team_lead_approval"] = True
    ticket = services.create_ticket(data, approval_request.items, requester, commit=False)
    approval_event = services.log_event(
        ticket,
        None,
        "STATUS_CHANGE",
        "Team Lead approval received; procurement case created.",
        old_status=None,
        new_status=ticket.status,
    )
    approval_event.actor_name = f"Team Lead ({approval_request.decision_comment})"
    approval_request.ticket_id = ticket.ticket_id
    db.session.commit()
    return ticket


def apply_team_lead_decision(approval_request, decision, actor_name):
    expired = datetime.now() >= approval_request.expires_at
    if approval_request.decision != "pending" or expired:
        abort(410, description="This Team Lead approval request is no longer active.")
    if decision not in {"approved", "technical_required"}:
        abort(400)
    if decision == "technical_required":
        if not requester_is_engineering(approval_request):
            abort(400, description="Technical approval escalation is only available for Engineering or Electronics requests.")
        approval_request.decision = "technical_pending"
        approval_request.decided_at = datetime.now()
        approval_request.decision_comment = actor_name
        approval_request.expires_at = datetime.now() + timedelta(days=7)
        db.session.commit()
        return "Sent to Rohit's Technical Approval inbox."
    approval_request.decided_at = datetime.now()
    approval_request.decision = "approved"
    approval_request.decision_comment = actor_name
    db.session.commit()
    return "Approved. The requester's department can now create the procurement case."


def render_team_lead_review(approval_request):
    payload = approval_request.payload
    project = db.session.get(Project, payload.get("project_id")) if payload.get("project_id") else None
    if payload.get("new_vendor"):
        vendor_details = dict(payload["new_vendor"])
        vendor_details["status"] = "New vendor suggested"
    elif payload.get("recommended_vendor_id"):
        vendor = db.session.get(Vendor, payload["recommended_vendor_id"])
        vendor_details = (
            {
                "name": vendor.name,
                "contact_person": vendor.contact_person,
                "email": vendor.email,
                "phone": vendor.phone,
                "address": vendor.address,
                "city": vendor.city,
                "country": vendor.country,
                "state": vendor.state_name,
                "gstin": vendor.gstin,
                "pan": vendor.pan,
                "payment_terms": vendor.payment_terms,
                "default_currency": vendor.default_currency,
                "notes": vendor.notes,
                "status": "Existing vendor",
            }
            if vendor
            else {"name": "Vendor unavailable"}
        )
    else:
        vendor_details = {"name": "Not decided yet"}
    expired = (
        approval_request.decision in {"pending", "technical_pending"}
        and datetime.now() >= approval_request.expires_at
    )
    return render_template(
        "team_lead_review.html",
        approval_request=approval_request,
        expired=expired,
        engineering_request=requester_is_engineering(approval_request),
        project_name=project.name if project else "No project",
        vendor_details=vendor_details,
    )


@bp.route("/team-lead-inbox")
def team_lead_inbox():
    require("review_team_lead")
    pending = db.session.scalars(
        select(TeamLeadApprovalRequest)
        .where(
            TeamLeadApprovalRequest.decision == "pending",
            TeamLeadApprovalRequest.expires_at > datetime.now(),
        )
        .order_by(TeamLeadApprovalRequest.created_at, TeamLeadApprovalRequest.id)
    ).all()
    approvals = [item for item in pending if is_team_lead_for_request(g.user, item)]
    return render_template("team_lead_inbox.html", approvals=approvals)


@bp.route("/team-lead-inbox/<int:request_id>", methods=["GET", "POST"])
def team_lead_inbox_review(request_id):
    require("review_team_lead")
    approval_request = db.session.get(TeamLeadApprovalRequest, request_id)
    if approval_request is None or not is_team_lead_for_request(g.user, approval_request):
        abort(404)
    if request.method == "POST":
        message = apply_team_lead_decision(
            approval_request, request.form.get("decision"), g.user.name
        )
        flash(message, "success")
    return render_team_lead_review(approval_request)


@bp.route("/team-lead-review/<token>", methods=["GET", "POST"])
def team_lead_review(token):
    approval_request = get_team_lead_request_or_404(token)
    if request.method == "POST":
        apply_team_lead_decision(
            approval_request,
            request.form.get("decision"),
            current_app.config["TEAM_LEAD_EMAIL"],
        )
    return render_team_lead_review(approval_request)


@bp.route("/team-lead-approved")
def team_lead_approved():
    require("engineering_requests")
    approved = db.session.scalars(
        select(TeamLeadApprovalRequest)
        .where(
            TeamLeadApprovalRequest.decision == "approved",
            TeamLeadApprovalRequest.ticket_id.is_(None),
        )
        .order_by(TeamLeadApprovalRequest.decided_at, TeamLeadApprovalRequest.id)
    ).all()
    approvals = [
        item for item in approved if same_department(g.user.department, item.requester.department)
    ]
    projects = {
        project.id: project.name
        for project in db.session.scalars(select(Project)).all()
    }
    return render_template("team_lead_approvals.html", approvals=approvals, projects=projects)


@bp.route("/team-lead-approved/<int:request_id>/create-case", methods=["POST"])
def create_approved_case(request_id):
    require("engineering_requests")
    approval_request = db.session.get(TeamLeadApprovalRequest, request_id)
    if (
        approval_request is None
        or not same_department(g.user.department, approval_request.requester.department)
    ):
        abort(404)
    ticket = create_ticket_from_team_lead_approval(approval_request)
    flash(f"Procurement case {ticket.ticket_id} created from the Team Lead approved request.", "success")
    return redirect(url_for("tickets.detail", ticket_id=ticket.ticket_id))


@bp.route("/technical-approvals")
def technical_approvals():
    require("review_technical")
    approvals = db.session.scalars(
        select(TeamLeadApprovalRequest)
        .where(
            TeamLeadApprovalRequest.decision == "technical_pending",
            TeamLeadApprovalRequest.expires_at > datetime.now(),
        )
        .order_by(TeamLeadApprovalRequest.decided_at, TeamLeadApprovalRequest.id)
    ).all()
    return render_template("technical_approvals.html", approvals=approvals)


@bp.route("/technical-review/<int:request_id>", methods=["GET", "POST"])
def technical_review(request_id):
    approver_email = current_app.config.get("TECHNICAL_APPROVER_EMAIL", "").strip().casefold()
    is_configured_approver = g.user and approver_email and g.user.email.casefold() == approver_email
    if not g.user or (g.user.role != ROLE_TECHNICAL_APPROVER and not is_configured_approver):
        abort(403, description="Sign in with the configured technical approver account to review this request.")

    approval_request = db.session.get(TeamLeadApprovalRequest, request_id)
    if approval_request is None:
        abort(404)
    if not requester_is_engineering(approval_request):
        abort(404)
    expired = approval_request.decision == "technical_pending" and datetime.now() >= approval_request.expires_at
    if request.method == "POST":
        if approval_request.decision != "technical_pending" or expired:
            abort(410, description="This technical approval request is no longer active.")
        if request.form.get("decision") != "approved":
            abort(400)
        approval_request.decision = "approved"
        approval_request.decided_at = datetime.now()
        lead_email = approval_request.decision_comment or "Team Lead"
        approval_request.decision_comment = f"{lead_email}; technical approval by {g.user.email}"
        db.session.commit()
        flash("Technical approval recorded. The requester's department can now create a case.", "success")
        return redirect(url_for("tickets.technical_review", request_id=request_id))

    payload = approval_request.payload
    project = db.session.get(Project, payload.get("project_id")) if payload.get("project_id") else None
    return render_template(
        "technical_review.html",
        approval_request=approval_request,
        expired=expired,
        project_name=project.name if project else "No project",
    )


@bp.route("/ticket/<ticket_id>")
def detail(ticket_id):
    return render_detail(get_ticket_or_404(ticket_id))


@bp.route("/ticket/<ticket_id>/attachments/<int:attachment_id>")
def download_attachment(ticket_id, attachment_id):
    ticket = get_ticket_or_404(ticket_id)
    attachment = db.session.get(RequestAttachment, attachment_id)
    if attachment is None or attachment.ticket_id != ticket.id:
        abort(404)
    response = send_file(
        BytesIO(attachment.data),
        mimetype=attachment.content_type,
        as_attachment=True,
        download_name=attachment.filename,
        max_age=0,
    )
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


@bp.route("/ticket/<ticket_id>/attachments", methods=["POST"])
def upload_attachments(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("upload_attachment", ticket)
    uploads = [file for file in request.files.getlist("documents") if file.filename]
    if not uploads:
        flash("Choose at least one document to upload.", "error")
        return to_detail(ticket)
    try:
        prepared = prepare_attachments(uploads)
    except ValueError as exc:
        flash(str(exc), "error")
        return to_detail(ticket)
    add_attachments(ticket, g.user, prepared)
    db.session.commit()
    count = len(prepared)
    flash(f"{count} document{'s' if count != 1 else ''} uploaded.", "success")
    return to_detail(ticket)


@bp.route("/ticket/<ticket_id>/photos", methods=["POST"])
def upload_stage_photos(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("upload_stage_photo", ticket)
    uploads = [file for file in request.files.getlist("photos") if file.filename]
    if not uploads:
        flash("Choose at least one photo to upload.", "error")
        return to_detail(ticket)

    prepared = []
    total_size = 0
    for upload in uploads:
        filename = secure_filename(upload.filename or "")
        suffix = "." + filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        image_type = PHOTO_TYPES.get(suffix)
        if not filename or image_type is None:
            flash("Upload JPG, PNG, or WebP images only.", "error")
            return to_detail(ticket)
        data = upload.stream.read(MAX_ATTACHMENT_BYTES + 1)
        total_size += len(data)
        content_type, signature = image_type
        valid_signature = data.startswith(signature)
        if suffix == ".webp":
            valid_signature = valid_signature and len(data) >= 12 and data[8:12] == b"WEBP"
        if not data or not valid_signature:
            flash(f"{filename} is not a valid {content_type} image.", "error")
            return to_detail(ticket)
        if len(data) > MAX_ATTACHMENT_BYTES or total_size > MAX_ATTACHMENT_BYTES:
            flash("The total photo upload size cannot exceed 10 MB at a time.", "error")
            return to_detail(ticket)
        prepared.append((filename, content_type, data))

    for filename, content_type, data in prepared:
        db.session.add(
            RequestPhoto(
                ticket_id=ticket.id,
                uploaded_by_id=g.user.id,
                filename=filename,
                content_type=content_type,
                size_bytes=len(data),
                data=data,
            )
        )
        services.log_event(ticket, g.user, "PHOTO_UPLOADED", comment=filename)
    db.session.commit()
    flash(f"{len(prepared)} photo{'s' if len(prepared) != 1 else ''} uploaded.", "success")
    return to_detail(ticket)


@bp.route("/ticket/<ticket_id>/photos/<int:photo_id>")
def view_stage_photo(ticket_id, photo_id):
    ticket = get_ticket_or_404(ticket_id)
    photo = db.session.get(RequestPhoto, photo_id)
    if photo is None or photo.ticket_id != ticket.id:
        abort(404)
    response = send_file(
        BytesIO(photo.data), mimetype=photo.content_type, download_name=photo.filename, max_age=0
    )
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


@bp.route("/ticket/<ticket_id>/edit", methods=["GET", "POST"])
def edit(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("edit", ticket)

    if request.method == "POST":
        with_items = can("edit_items", ticket)
        data, items, errors = validate_request_form(
            request.form, with_requisition=with_items, ticket=ticket
        )
        if with_items and not errors:
            errors = services.check_item_changes(ticket, items)
        if errors:
            return render_form(
                "edit", request.form, errors, item_rows_from_form(request.form), ticket
            )
        changes = services.edit_ticket(ticket, g.user, data, items)
        db.session.commit()
        flash(
            "Changes saved." if changes else "No changes to save.", "success" if changes else "info"
        )
        return to_detail(ticket)

    values = {
        "title": ticket.title or "",
        "project_id": str(ticket.project_id or ""),
        "owner": ticket.owner or "",
        "category": ticket.category,
        "procurement_type": ticket.procurement_type,
        "priority": ticket.priority,
        "team_lead_approval": "yes" if ticket.team_lead_approval else "no",
        "required_by": ticket.required_by.isoformat() if ticket.required_by else "",
        "description": ticket.description or "",
        "recommended_vendor_id": str(ticket.recommended_vendor_id or ""),
    }
    rows = [
        {"id": str(i.id), "description": i.description, "quantity": str(i.quantity), "unit": i.unit}
        for i in ticket.items
    ]
    return render_form("edit", values, {}, rows, ticket)


@bp.route("/ticket/<ticket_id>/prices", methods=["POST"])
def update_prices(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("pricing", ticket)
    prices, errors = validate_pricing_form(request.form, ticket)
    if errors:
        flash(" ".join(errors.values()), "error")
        return to_detail(ticket)
    changes = services.update_prices(ticket, g.user, prices)
    db.session.commit()
    flash("Prices saved." if changes else "No changes to save.", "success" if changes else "info")
    return to_detail(ticket)


@bp.route("/ticket/<ticket_id>/requisition/print")
def print_requisition(ticket_id):
    """The Purchase Requisition Form, in ERIC's paper format."""
    ticket = get_ticket_or_404(ticket_id)
    sent = latest_event(ticket, "STATUS_CHANGE", new_status=APPROVAL_STAGE)
    approved = latest_event(ticket, "APPROVED")
    # the requisitioner is the engineer who raised it; tickets from before
    # V0.5 have no creator, so fall back to whoever sent it for approval
    requisitioner = ticket.created_by
    if requisitioner is None and sent and sent.user_id:
        requisitioner = db.session.get(User, sent.user_id)
    return render_template(
        "requisition_print.html",
        ticket=ticket,
        company=CompanySettings.get(),
        # [(item, its most recent earlier PO line)] for items bought before
        last_purchases=[
            (item, line)
            for item in ticket.items
            if (line := purchasing.last_purchase(item)) is not None
        ],
        sent=sent,
        approved=approved,
        requisitioner=requisitioner,
    )


@bp.route("/ticket/<ticket_id>/quotation/print")
def print_quotation(ticket_id):
    """Print the vendor and item pricing captured for the approved requisition."""
    ticket = get_ticket_or_404(ticket_id)
    return render_template(
        "quotation_print.html",
        ticket=ticket,
        company=CompanySettings.get(),
    )


@bp.route("/ticket/<ticket_id>/tracking", methods=["POST"])
def update_tracking(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("tracking", ticket)
    if not ticket.in_tracking:
        flash("Tracking details can be recorded once the PO is released.", "error")
        return to_detail(ticket)

    # vendor / PO number text boxes only for older tickets without real POs
    data, comment, errors = validate_tracking_form(
        request.form, include_vendor_fields=not ticket.po_lines
    )
    if errors:
        return render_detail(ticket, tracking_values=request.form, tracking_errors=errors)

    changes = services.update_tracking(ticket, g.user, data, comment)
    db.session.commit()
    if changes or comment:
        flash("Tracking details saved.", "success")
    else:
        flash("No changes to save.", "info")
    return to_detail(ticket)


@bp.route("/ticket/<ticket_id>/payments", methods=["POST"])
def record_payment(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("record_payment", ticket)
    data, errors = validate_payment_form(request.form, ticket)
    uploads = [file for file in request.files.getlist("documents") if file.filename]
    prepared = []
    if not errors and uploads:
        try:
            prepared = prepare_attachments(uploads)
        except ValueError as exc:
            errors["documents"] = str(exc)
    if errors:
        return render_detail(ticket, payment_values=request.form, payment_errors=errors)

    services.record_payment(ticket, g.user, data)
    if prepared:
        add_attachments(ticket, g.user, prepared)
    db.session.commit()
    flash("Payment recorded and remaining balance updated.", "success")
    return to_detail(ticket)


# ---- workflow actions ----

# action in URL -> (service function, reason required?, success message)
WORKFLOW_ACTIONS = {
    "advance": (services.advance, False, "Moved to {status}."),
    "send-back": (services.send_back, False, "Sent back to {status}."),
    "set-stage": (services.set_stage, False, "Moved to {status}."),
    "hold": (services.hold, True, "Case put on hold."),
    "resume": (services.resume, False, "Case resumed."),
    "cancel": (services.cancel, True, "Case cancelled."),
    "reopen": (services.reopen, True, "Case reopened."),
}


@bp.route(
    "/ticket/<ticket_id>/<any(advance,'send-back','set-stage',hold,resume,cancel,reopen):action>",
    methods=["POST"],
)
def workflow_action(ticket_id, action):
    ticket = get_ticket_or_404(ticket_id)
    require(action, ticket)
    service, reason_required, message = WORKFLOW_ACTIONS[action]
    old_stage = ticket.status
    was_at_approval = ticket.status in APPROVAL_STAGES

    target_stage = request.form.get("target_stage") if action in ("send-back", "set-stage") else None
    if action == "set-stage" and not target_stage:
        flash("Choose a stage.", "error")
        return to_detail(ticket)
    comment, errors = validate_comment(request.form, required=reason_required)
    if errors:
        flash(errors["comment"], "error")
        return to_detail(ticket)

    uploads = [file for file in request.files.getlist("documents") if file.filename]
    prepared_attachments = []
    if uploads:
        if action != "advance":
            abort(400)
        require("upload_attachment", ticket)
        try:
            prepared_attachments = prepare_attachments(uploads)
        except ValueError as exc:
            flash(str(exc), "error")
            return to_detail(ticket)

    try:
        add_attachments(ticket, g.user, prepared_attachments)
        if action == "set-stage" and target_stage:
            services.set_stage(ticket, g.user, target_stage, comment)
        elif action == "send-back" and target_stage:
            services.send_back_to(ticket, g.user, target_stage, comment)
        else:
            service(ticket, g.user, comment)
    except services.WorkflowError as exc:
        db.session.rollback()
        flash(str(exc), "error")
        return to_detail(ticket)

    db.session.commit()
    if (
        old_stage != "Payment Processing"
        and ticket.status == "Payment Processing"
        and g.user.role == ROLE_PURCHASE
        and (g.user.name or "").strip().casefold() == "sonu"
    ):
        sagar = db.session.scalars(
            select(User).where(
                User.active.is_(True),
                User.role == ROLE_PR_APPROVER,
                func.lower(func.trim(User.name)) == "sagar",
            )
        ).all()
        for account_user in sagar:
            db.session.add(
                UserNotification(
                    recipient_id=account_user.id,
                    ticket_id=ticket.id,
                    message=f"{ticket.ticket_id} is ready for payment processing.",
                )
            )
        if sagar:
            db.session.commit()
    if was_at_approval and action == "advance":
        message = "Approved. Moved to {status}."
    elif was_at_approval and action == "send-back" and g.user.role in (
        ROLE_APPROVER,
        ROLE_PR_APPROVER,
    ):
        message = "Rejected. Sent back to {status}."
    if prepared_attachments:
        count = len(prepared_attachments)
        message += f" {count} document{'s' if count != 1 else ''} uploaded."
    flash(message.format(status=ticket.status), "success")
    if action == "set-stage" and ticket.status == "Payment Processing":
        return redirect(url_for("tickets.detail", ticket_id=ticket.ticket_id) + "#payment-entry")
    return to_detail(ticket)


# ---- case management ----


@bp.route("/ticket/<ticket_id>/archive", methods=["POST"])
def archive_ticket(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("archive", ticket)
    services.set_archived(ticket, g.user, True)
    db.session.commit()
    flash(f"{ticket.ticket_id} archived.", "success")
    return redirect(url_for("tickets.queue"))


@bp.route("/ticket/<ticket_id>/restore", methods=["POST"])
def restore_ticket(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("restore", ticket)
    services.set_archived(ticket, g.user, False)
    db.session.commit()
    flash(f"{ticket.ticket_id} restored.", "success")
    return to_detail(ticket)


@bp.route("/ticket/<ticket_id>/delete", methods=["POST"])
def delete_ticket(ticket_id):
    ticket = get_ticket_or_404(ticket_id)
    require("delete", ticket)
    services.delete_ticket(ticket)
    db.session.commit()
    flash(f"{ticket_id} permanently deleted.", "success")
    return redirect(url_for("tickets.queue"))
