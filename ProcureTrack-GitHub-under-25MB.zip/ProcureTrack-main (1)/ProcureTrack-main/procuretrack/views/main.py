"""Dashboard (counts, recent tickets, the approver's to-do list) and Reports."""

from datetime import date, datetime
from io import BytesIO

from flask import Blueprint, Response, current_app, g, render_template, send_file, url_for
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from sqlalchemy import func, select

from .. import __version__
from ..constants import APPROVAL_STAGES, FINAL_STAGE, STATE_ACTIVE, STATE_CANCELLED, STATE_ON_HOLD
from ..extensions import db
from ..models import ProcurementRequest as PR, UserNotification
from ..permissions import can

bp = Blueprint("main", __name__)


@bp.app_context_processor
def notification_context():
    user = g.get("user")
    unread = 0
    if user is not None:
        unread = db.session.scalar(
            select(func.count(UserNotification.id)).where(
                UserNotification.recipient_id == user.id,
                UserNotification.read_at.is_(None),
            )
        ) or 0
    return {"unread_notification_count": unread}


def count(*conditions):
    """Number of non-archived tickets matching the conditions."""
    return db.session.scalar(
        select(func.count()).select_from(PR).where(PR.archived.is_(False), *conditions)
    )


@bp.route("/")
def dashboard():
    stats = {
        "active": count(PR.state == STATE_ACTIVE, PR.status != FINAL_STAGE),
        "approval": count(PR.state == STATE_ACTIVE, PR.status.in_(APPROVAL_STAGES)),
        "payment": count(PR.state == STATE_ACTIVE, PR.status == "Payment Processing"),
        "transit": count(PR.state == STATE_ACTIVE, PR.status == "In Transit"),
        "on_hold": count(PR.state == STATE_ON_HOLD),
        "overdue": count(
            PR.required_by < date.today(),
            PR.status != FINAL_STAGE,
            PR.state != STATE_CANCELLED,
        ),
    }
    recent = db.session.scalars(
        select(PR).where(PR.archived.is_(False)).order_by(PR.id.desc()).limit(5)
    ).all()

    approval_candidates = db.session.scalars(
        select(PR)
        .where(
            PR.archived.is_(False),
            PR.state == STATE_ACTIVE,
            PR.status.in_(APPROVAL_STAGES),
        )
        .order_by(PR.id)
    ).all()
    my_approvals = [ticket for ticket in approval_candidates if can("advance", ticket)]

    return render_template("dashboard.html", stats=stats, recent=recent, my_approvals=my_approvals)


@bp.route("/manifest.webmanifest")
def manifest():
    return {
        "id": "/",
        "name": "ProcureTrack | ERIC Robotics",
        "short_name": "ProcureTrack",
        "start_url": "/",
        "scope": "/",
        "display": "standalone",
        "background_color": "#F5F8FC",
        "theme_color": "#0057B8",
        "icons": [
            {
                "src": url_for("static", filename="assets/procuretrack-192.png"),
                "sizes": "192x192",
                "type": "image/png",
                "purpose": "any maskable",
            },
            {
                "src": url_for("static", filename="assets/procuretrack-512.png"),
                "sizes": "512x512",
                "type": "image/png",
                "purpose": "any maskable",
            },
        ],
    }


@bp.route("/service-worker.js")
def service_worker():
    response = Response(
        "self.addEventListener('install', event => self.skipWaiting());\n"
        "self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));\n"
        "self.addEventListener('fetch', event => event.respondWith(fetch(event.request)));\n",
        mimetype="application/javascript",
    )
    response.headers["Service-Worker-Allowed"] = "/"
    response.headers["Cache-Control"] = "no-cache"
    return response


@bp.route("/health")
def health():
    """For the hosting platform's health check / uptime monitor. No sign-in needed."""
    try:
        db.session.execute(select(1))
    except Exception:
        current_app.logger.exception("Health check: database not reachable")
        return {"status": "error", "database": "unreachable"}, 503
    return {"status": "ok", "version": __version__}


@bp.route("/notifications")
def notifications():
    user = g.user
    entries = db.session.scalars(
        select(UserNotification)
        .where(UserNotification.recipient_id == user.id)
        .order_by(UserNotification.created_at.desc(), UserNotification.id.desc())
    ).all()
    now = datetime.now()
    for entry in entries:
        if entry.read_at is None:
            entry.read_at = now
    if entries:
        db.session.commit()
    return render_template("notifications.html", notifications=entries)


@bp.route("/reports")
def reports():
    tickets = db.session.scalars(
        select(PR).order_by(PR.request_date.desc(), PR.id.desc())
    ).all()
    return render_template("reports.html", tickets=tickets)


def _excel_value(value):
    """Keep user-entered text from being interpreted as an Excel formula."""
    if isinstance(value, str) and value.startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


def _add_sheet(workbook, title, headers, rows, currency_columns=()):
    sheet = workbook.create_sheet(title)
    sheet.append(headers)
    for row in rows:
        sheet.append([_excel_value(value) for value in row])

    header_fill = PatternFill("solid", fgColor="DCEBFA")
    for cell in sheet[1]:
        cell.font = Font(bold=True, color="17365D")
        cell.fill = header_fill
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions
    sheet.row_dimensions[1].height = 30
    for column in range(1, sheet.max_column + 1):
        values = [str(sheet.cell(row, column).value or "") for row in range(1, min(sheet.max_row, 100) + 1)]
        sheet.column_dimensions[get_column_letter(column)].width = min(max(max(map(len, values), default=10) + 2, 12), 38)
    for column in currency_columns:
        for cell in sheet.iter_cols(min_col=column, max_col=column, min_row=2):
            for value_cell in cell:
                value_cell.number_format = '₹#,##0.00;[Red]-₹#,##0.00'
    return sheet


@bp.route("/reports/export.xlsx")
def export_reports():
    """Download a workbook with one ticket register and normalized detail sheets."""
    tickets = db.session.scalars(
        select(PR).order_by(PR.request_date.desc(), PR.id.desc())
    ).all()

    workbook = Workbook()
    workbook.remove(workbook.active)
    headers = [
        "Ticket ID", "Title", "Items", "Requested By", "Request Owner", "Project",
        "Category", "Procurement Type", "Priority", "Team Lead Approval",
        "Recommended Vendor", "Selected Vendor", "Request Date", "Required By",
        "Current Stage", "State", "Archived", "PO Number", "Total (INR)",
        "Paid To Date (INR)", "Remaining Balance (INR)", "Payment Status",
        "Fulfilment Status", "Expected Delivery", "Requirement Description",
    ]
    register_rows = []
    item_rows = []
    payment_rows = []
    for ticket in tickets:
        estimate = ticket.payment_total
        register_rows.append([
            ticket.ticket_id, ticket.title or ticket.summary,
            "; ".join(f"{item.description} ({item.quantity} {item.unit})" for item in ticket.items),
            ticket.created_by.name if ticket.created_by else "", ticket.owner or "",
            ticket.project.name if ticket.project else "", ticket.category or "",
            ticket.procurement_type or "", ticket.priority,
            "Yes" if ticket.team_lead_approval else "No",
            ticket.recommended_vendor.name if ticket.recommended_vendor else "",
            ticket.selected_vendor or "", ticket.request_date, ticket.required_by,
            ticket.status, ticket.state, "Yes" if ticket.archived else "No",
            ticket.po_number or "", estimate, ticket.amount_paid, ticket.remaining_balance,
            ticket.payment_status, ticket.fulfilment_status, ticket.expected_delivery,
            ticket.description or "",
        ])
        for item in ticket.items:
            item_rows.append([
                ticket.ticket_id, ticket.title or ticket.summary, item.position,
                item.description, item.quantity, item.unit,
                item.est_unit_price, item.est_gst_rate,
                item.estimate.total if item.estimate else None,
            ])
        for payment in ticket.payments:
            payment_rows.append([
                ticket.ticket_id, ticket.title or ticket.summary, payment.paid_on,
                payment.amount, payment.method, payment.reference or "",
                payment.notes or "", payment.recorded_by.name if payment.recorded_by else "",
            ])

    register = _add_sheet(workbook, "Procurement Register", headers, register_rows, (19, 20, 21))
    for column in (13, 14, 24):
        for row in register.iter_rows(min_row=2, min_col=column, max_col=column):
            row[0].number_format = "dd-mmm-yyyy"
    _add_sheet(workbook, "Items", [
        "Ticket ID", "Title", "Item No.", "Item Description", "Quantity", "Unit",
        "Unit Price (INR, excl. GST)", "GST %", "Estimated Total (INR, incl. GST)",
    ], item_rows, (7, 9))
    payments = _add_sheet(workbook, "Payments", [
        "Ticket ID", "Title", "Payment Date", "Amount (INR)", "Payment Method",
        "Reference Number", "Notes", "Recorded By",
    ], payment_rows, (4,))
    for row in payments.iter_rows(min_row=2, min_col=3, max_col=3):
        row[0].number_format = "dd-mmm-yyyy"

    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return send_file(
        output,
        as_attachment=True,
        download_name=f"procurement-report-{date.today().isoformat()}.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
