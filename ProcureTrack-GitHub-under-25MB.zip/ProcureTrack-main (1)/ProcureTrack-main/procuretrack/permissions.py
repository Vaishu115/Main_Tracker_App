"""
Who may do what. Every permission check in the app goes through can().

Roles (one per user) plus a separate admin flag:

  Requester      Raise tickets (choosing the vendor and the items) and view
                 all of them. Edit or cancel their own ticket until PR Release.
  Purchase team  Run the procurement process: add the prices, change the
                 vendor or items until approval, move stages, tracking,
                 hold / send back / cancel / reopen, archive; manage
                 vendors, projects and purchase orders.
  Purchase team · PR approver  Approve or reject tickets at PR Release (Sagar).
  Approver       Approve or reject tickets at PO Release Approval (Chirag).
  Admin (flag)   Everything the purchase team can do, plus manage users,
                 company settings and permanently delete. Admin does NOT include approving;
                 assign the PR approver for PR Release and Approver for PO Release Approval.

Approvers may approve their own tickets while ALLOW_SELF_APPROVAL is True
(config.py); the timeline then marks the approval "Self-approved".
"""

from flask import abort, current_app, g
from sqlalchemy import func, select

from .constants import APPROVAL_STAGE, APPROVAL_STAGES, PROCUREMENT_FLOW, RFQ_STAGE, STATE_ACTIVE
from .extensions import db
from .models import (
    ROLE_APPROVER,
    ROLE_PR_APPROVER,
    ROLE_PURCHASE,
    ROLE_TEAM_LEAD,
    ROLE_TECHNICAL_APPROVER,
    User,
)

APPROVAL_INDEX = PROCUREMENT_FLOW.index(APPROVAL_STAGE)


def is_staff(user):
    """Runs the procurement process (purchase team or admin)."""
    return user.role in (ROLE_PURCHASE, ROLE_PR_APPROVER) or user.is_admin


def same_department(first, second):
    return bool(first and second and first.strip().casefold() == second.strip().casefold())


def department_has_team_lead(department):
    if not department:
        return False
    return db.session.scalar(
        select(User.id)
        .where(
            User.active.is_(True),
            User.role == ROLE_TEAM_LEAD,
            func.lower(func.trim(User.department)) == department.strip().casefold(),
        )
        .limit(1)
    ) is not None


def is_team_department_member(user):
    """Whether this user belongs to a department with an active Team Lead."""
    return bool(user and user.department and department_has_team_lead(user.department))


def is_team_lead_for_request(user, approval_request):
    requester = approval_request.requester if approval_request else None
    return bool(
        user
        and user.role == ROLE_TEAM_LEAD
        and requester
        and same_department(user.department, requester.department)
    )


def owns(user, ticket):
    return (
        ticket is not None and ticket.created_by_id is not None and ticket.created_by_id == user.id
    )


def before_approval(ticket):
    return ticket.stage_index is not None and ticket.stage_index < APPROVAL_INDEX


def at_approval(ticket):
    return ticket is not None and ticket.status in APPROVAL_STAGES


def requisition_open(ticket):
    """Vendor, items and prices can change up to Approval Pending, then they're locked."""
    return (
        ticket.state == STATE_ACTIVE
        and not ticket.archived
        and ticket.stage_index is not None
        and ticket.stage_index <= APPROVAL_INDEX
    )


def can_approve(user, ticket):
    required_role = {
        APPROVAL_STAGE: ROLE_PR_APPROVER,
        "PO Release Pending": ROLE_APPROVER,
    }.get(ticket.status if ticket else None)
    if required_role is None or user.role != required_role or not at_approval(ticket):
        return False
    return not owns(user, ticket) or current_app.config["ALLOW_SELF_APPROVAL"]


def can(action, ticket=None, user=None):
    user = user if user is not None else g.get("user")
    if user is None or not user.active:
        return False

    staff = is_staff(user)

    if action == "create":
        return True
    if action == "engineering_requests":
        return is_team_department_member(user)
    if action == "request_team_lead_approval":
        return is_team_department_member(user) and user.role != ROLE_TEAM_LEAD
    if action == "review_team_lead":
        return user.role == ROLE_TEAM_LEAD
    if action == "review_technical":
        return user.role == ROLE_TECHNICAL_APPROVER
    if action == "edit":
        return staff or (
            owns(user, ticket)
            and before_approval(ticket)
            and ticket.state == STATE_ACTIVE
            and not ticket.archived
        )
    if action == "advance":
        # moving past Approval Pending is approving
        return can_approve(user, ticket) if at_approval(ticket) else staff
    if action == "send-back":
        return staff or can_approve(user, ticket)
    if action == "set-stage":
        return staff
    if action == "cancel":
        return (
            staff or can_approve(user, ticket) or (owns(user, ticket) and before_approval(ticket))
        )
    if action in ("hold", "resume", "reopen", "tracking", "archive", "restore"):
        return staff
    # the requisition is locked once approved, so the approved figures stay
    if action == "edit_items":
        # vendor and item rows: the engineer who raised it (before approval) or purchase
        return requisition_open(ticket) and (
            staff or (owns(user, ticket) and before_approval(ticket))
        )
    if action == "pricing":
        # estimated price and GST per item, from the vendor's quotation
        return staff and requisition_open(ticket)
    if action == "record_payment":
        return (
            staff
            and ticket is not None
            and ticket.status == "Payment Processing"
            and ticket.state == STATE_ACTIVE
            and not ticket.archived
        )
    if action == "upload_attachment":
        return (
            staff
            and ticket is not None
            and ticket.status
            in (
                RFQ_STAGE,
                "Vendor Selected",
                "Received",
                "Inspection",
                "Payment Processing",
                "PO Release Pending",
                "PO Released",
            )
            and ticket.state == STATE_ACTIVE
            and not ticket.archived
        )
    if action == "upload_stage_photo":
        return (
            staff
            and ticket is not None
            and ticket.status in ("Received", "Inspection")
            and ticket.state == STATE_ACTIVE
            and not ticket.archived
        )
    # purchasing: vendors, projects and POs (everyone signed in can view them)
    if action in ("manage_vendors", "manage_projects", "manage_pos"):
        return staff
    if action in ("delete", "manage_users", "company_settings"):
        return user.is_admin

    raise ValueError(f"Unknown permission: {action}")


def require(action, ticket=None):
    if not can(action, ticket):
        abort(403)
