"""SMTP notifications for procurement workflow events."""

import smtplib
import ssl
from email.message import EmailMessage

from flask import current_app, url_for
from sqlalchemy import select

from .extensions import db
from .models import ROLE_APPROVER, ROLE_TEAM_LEAD, User


def send_team_lead_notification(ticket):
    """Notify the Team Lead about a created case that did not need approval."""
    config = current_app.config
    team_lead_email = config["TEAM_LEAD_EMAIL"]
    if not config.get("SMTP_HOST") or not config.get("SMTP_FROM"):
        current_app.logger.warning(
            "Team Lead notification skipped for ticket %s: SMTP host/from is not configured",
            ticket.ticket_id,
        )
        return False

    link = url_for("tickets.detail", ticket_id=ticket.ticket_id, _external=True)
    items = "\n".join(
        f"- {item.description}: {item.quantity} {item.unit}" for item in ticket.items
    )
    message = EmailMessage()
    message["Subject"] = f"ProcureTrack request notification: {ticket.ticket_id}"
    message["From"] = config["SMTP_FROM"]
    message["To"] = team_lead_email
    message.set_content(
        f"A procurement case was created; no Team Lead approval was requested.\n\n"
        f"Case: {ticket.ticket_id}\n"
        f"Request: {ticket.summary}\n"
        f"Requested by: {ticket.created_by.name if ticket.created_by else ticket.owner or 'Unknown'}\n"
        f"Items:\n{items or '- None'}\n\n"
        f"View the case in ProcureTrack: {link}\n"
    )
    return _deliver(message, [team_lead_email], ticket.ticket_id)


def send_team_lead_approval(approval_request):
    """Email department Team Lead(s) with a link to their authenticated inbox review."""
    config = current_app.config
    requester = approval_request.requester
    department = (requester.department or "").strip().casefold() if requester else ""
    team_lead_emails = [
        user.email
        for user in db.session.scalars(
            select(User).where(
                User.active.is_(True),
                User.role == ROLE_TEAM_LEAD,
                User.department.is_not(None),
            )
        ).all()
        if department and (user.department or "").strip().casefold() == department
    ]
    if not config.get("SMTP_HOST") or not config.get("SMTP_FROM"):
        current_app.logger.warning(
            "Team Lead approval email skipped for request %s: SMTP host/from is not configured",
            approval_request.id,
        )
        return False
    if not team_lead_emails:
        current_app.logger.warning(
            "Team Lead approval email skipped for request %s: no active Team Lead email for department %s",
            approval_request.id,
            department or "(none)",
        )
        return False

    link = url_for(
        "tickets.team_lead_inbox_review",
        request_id=approval_request.id,
        _external=True,
    )
    data = approval_request.payload
    items = "\n".join(
        f"- {item['description']}: {item['quantity']} {item['unit']}"
        for item in approval_request.items
    )
    message = EmailMessage()
    request_title = data.get("title") or (
        approval_request.items[0]["description"] if approval_request.items else "New request"
    )
    message["Subject"] = f"Team Lead approval requested: {request_title}"
    message["From"] = config["SMTP_FROM"]
    message["To"] = ", ".join(team_lead_emails)
    message.set_content(
        f"A procurement request is waiting for your Team Lead approval.\n\n"
        f"Title: {data.get('title') or (approval_request.items[0]['description'] if approval_request.items else 'New request')}\n"
        f"Requested by: {approval_request.requester.name}\n"
        f"Owner: {data.get('owner') or '-'}\n"
        f"Priority: {data.get('priority') or '-'}\n"
        f"Items:\n{items or '- None'}\n\n"
        f"Description:\n{data.get('description') or '-'}\n\n"
        f"Sign in to ProcureTrack and review this request: {link}\n\n"
        "The request expires in 7 days."
    )
    return _deliver(message, team_lead_emails, f"team-lead-request-{approval_request.id}")


def send_technical_approval_request(approval_request):
    """Ask the configured technical approver to sign in and review an Engineering request."""
    config = current_app.config
    recipient = config.get("TECHNICAL_APPROVER_EMAIL", "").strip()
    if not recipient or not config.get("SMTP_HOST") or not config.get("SMTP_FROM"):
        current_app.logger.warning(
            "Technical approval email skipped for request %s: recipient or SMTP is not configured",
            approval_request.id,
        )
        return False

    link = url_for("tickets.technical_review", request_id=approval_request.id, _external=True)
    data = approval_request.payload
    items = "\n".join(
        f"- {item['description']}: {item['quantity']} {item['unit']}"
        for item in approval_request.items
    )
    title = data.get("title") or (
        approval_request.items[0]["description"] if approval_request.items else "New request"
    )
    message = EmailMessage()
    message["Subject"] = f"Technical approval requested: {title}"
    message["From"] = config["SMTP_FROM"]
    message["To"] = recipient
    message.set_content(
        f"The Team Lead requested technical approval for an Engineering procurement request.\n\n"
        f"Title: {title}\n"
        f"Requested by: {approval_request.requester.name}\n"
        f"Items:\n{items or '- None'}\n\n"
        f"Sign in to ProcureTrack to review and approve: {link}\n"
    )
    return _deliver(message, [recipient], f"technical-approval-request-{approval_request.id}")

def notify_approvers(ticket):
    """Email active approvers when a ticket is submitted for approval."""
    config = current_app.config
    host = config.get("SMTP_HOST")
    sender = config.get("SMTP_FROM")
    if not host or not sender:
        current_app.logger.info(
            "Approval email skipped: SMTP host/from address is not configured"
        )
        return

    recipients = db.session.scalars(
        select(User.email).where(
            User.role == ROLE_APPROVER,
            User.active.is_(True),
        )
    ).all()
    if not recipients:
        current_app.logger.info("Approval email skipped for %s: no active approvers", ticket.ticket_id)
        return

    link = url_for("tickets.detail", ticket_id=ticket.ticket_id, _external=True)
    subject = f"ProcureTrack approval required: {ticket.ticket_id}"
    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = sender
    message["To"] = ", ".join(recipients)
    message.set_content(
        f"{ticket.ticket_id} is waiting for your approval.\n\n"
        f"Request: {ticket.summary}\n"
        f"Requested by: {ticket.created_by.name if ticket.created_by else ticket.owner or 'Unknown'}\n"
        f"Open ProcureTrack: {link}\n"
    )

    _deliver(message, recipients, ticket.ticket_id)


def _deliver(message, recipients, ticket_id):
    config = current_app.config
    host = config.get("SMTP_HOST")
    sender = config.get("SMTP_FROM")
    if not host or not sender:
        return False

    security = config.get("SMTP_SECURITY", "ssl")
    try:
        if security == "ssl":
            with smtplib.SMTP_SSL(
                host,
                config.get("SMTP_PORT", 465),
                timeout=15,
                context=ssl.create_default_context(),
            ) as client:
                _send(client, config, sender, recipients, message)
        elif security == "starttls":
            with smtplib.SMTP(host, config.get("SMTP_PORT", 587), timeout=15) as client:
                client.starttls(context=ssl.create_default_context())
                _send(client, config, sender, recipients, message)
        else:
            raise ValueError("SMTP_SECURITY must be 'ssl' or 'starttls'")
        return True
    except Exception:
        # Sending happens after the ticket commit; a mail outage must not undo workflow data.
        current_app.logger.exception("Email delivery failed for %s", ticket_id)
        return False


def _send(client, config, sender, recipients, message):
    username = config.get("SMTP_USERNAME")
    password = config.get("SMTP_PASSWORD")
    if username:
        client.login(username, password or "")
    client.send_message(message, from_addr=sender, to_addrs=recipients)
