"""Cloudflare Python Worker entry point for the ProcureTrack Flask application."""

import asyncio
import json
from pathlib import Path, PurePosixPath

import jwt
from flask import Response
from jinja2 import BaseLoader, TemplateNotFound
from js import fetch
from sqlalchemy.engine import URL
from sqlalchemy.pool import NullPool
from workers import WorkerEntrypoint, wsgi

from procuretrack import create_app
from procuretrack.access_keys import cache_access_jwks, get_access_jwk

_app = None
_request_lock = asyncio.Lock()


def env_value(env, name, default=""):
    value = getattr(env, name, None)
    return default if value is None else str(value)


def create_worker_app(env):
    """Build Flask configuration from Cloudflare bindings and encrypted secrets."""
    hyperdrive = env.HYPERDRIVE
    database_url = URL.create(
        "postgresql+pg8000",
        username=str(hyperdrive.user),
        password=str(hyperdrive.password),
        host=str(hyperdrive.host),
        port=int(hyperdrive.port),
        database=str(hyperdrive.database),
    ).render_as_string(hide_password=False)

    access_domain = env_value(env, "PROCURETRACK_ACCESS_TEAM_DOMAIN").removeprefix(
        "https://"
    ).rstrip("/")
    access_audience = env_value(env, "PROCURETRACK_ACCESS_AUD")
    secret_key = env_value(env, "PROCURETRACK_SECRET_KEY")
    if not access_domain or not access_audience or not secret_key:
        raise RuntimeError(
            "Set the Cloudflare Access domain, audience, and ProcureTrack secret key."
        )

    admin_emails = {
        email.strip().lower()
        for email in env_value(env, "PROCURETRACK_ADMIN_EMAILS").split(",")
        if email.strip()
    }
    overrides = {
        "CLOUDFLARE_WORKER": True,
        "PRODUCTION": True,
        "AUTH_MODE": "cloudflare_access",
        "SESSION_COOKIE_SECURE": True,
        "ACCESS_TEAM_DOMAIN": access_domain,
        "ACCESS_AUD": access_audience,
        "ADMIN_EMAILS": admin_emails,
        "SECRET_KEY": secret_key,
        "DATA_DIR": Path("/tmp/procuretrack"),
        "LEGACY_DB_PATH": None,
        "AUTO_MIGRATE": False,
        "SQLALCHEMY_DATABASE_URI": database_url,
        # Hyperdrive pools connections at the edge. Do not retain socket-backed
        # SQLAlchemy connections between Worker requests.
        "SQLALCHEMY_ENGINE_OPTIONS": {"poolclass": NullPool},
        "TEAM_LEAD_EMAIL": env_value(
            env, "PROCURETRACK_TEAM_LEAD_EMAIL", "vaishnavi.kulkarni@ericrobotics.com"
        ),
        "TECHNICAL_APPROVER_EMAIL": env_value(
            env, "PROCURETRACK_TECHNICAL_APPROVER_EMAIL"
        ),
        "SMTP_HOST": env_value(env, "PROCURETRACK_SMTP_HOST"),
        "SMTP_PORT": int(env_value(env, "PROCURETRACK_SMTP_PORT", "465")),
        "SMTP_USERNAME": env_value(env, "PROCURETRACK_SMTP_USERNAME"),
        "SMTP_PASSWORD": env_value(env, "PROCURETRACK_SMTP_PASSWORD"),
        "SMTP_FROM": env_value(env, "PROCURETRACK_SMTP_FROM"),
        "SMTP_SECURITY": env_value(env, "PROCURETRACK_SMTP_SECURITY", "ssl").lower(),
    }
    app = create_app(overrides)
    app.jinja_loader = WorkerTemplateLoader()
    app.add_url_rule(
        "/static/<path:filename>",
        endpoint="static",
        view_func=serve_worker_static_asset,
        methods=["GET", "HEAD"],
    )
    return app


class WorkerTemplateLoader(BaseLoader):
    """Load templates embedded into the Worker bundle."""

    def get_source(self, environment, template):
        template_path = PurePosixPath(template.replace("\\", "/"))
        if template_path.is_absolute() or ".." in template_path.parts:
            raise TemplateNotFound(template)
        try:
            from procuretrack_worker_templates import TEMPLATES

            source = TEMPLATES[template_path.as_posix()]
        except (ImportError, KeyError) as exc:
            raise TemplateNotFound(template) from exc
        return source, template_path.as_posix(), lambda: True


def serve_worker_static_asset(filename):
    return "Not found", 404


async def prepare_access_jwks(request, env):
    token = request.headers.get("Cf-Access-Jwt-Assertion", "")
    if not token:
        return
    team_domain = env_value(env, "PROCURETRACK_ACCESS_TEAM_DOMAIN").removeprefix(
        "https://"
    ).rstrip("/")
    if not team_domain:
        return
    try:
        key_id = jwt.get_unverified_header(token).get("kid")
    except jwt.PyJWTError:
        return
    if get_access_jwk(team_domain, key_id) is not None:
        return

    response = await fetch(f"https://{team_domain}/cdn-cgi/access/certs")
    if not response.ok:
        raise RuntimeError(f"Cloudflare Access JWKS request returned HTTP {response.status}")
    jwks = json.loads(await response.text())
    cache_access_jwks(team_domain, jwks)


class Default(WorkerEntrypoint):
    async def fetch(self, request):
        global _app
        await prepare_access_jwks(request, self.env)
        async with _request_lock:
            if _app is None:
                _app = create_worker_app(self.env)
            return await wsgi.fetch(_app, request, self.env)
