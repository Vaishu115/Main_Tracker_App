import { DurableObject } from "cloudflare:workers";

const RUNTIME_SECRET_NAMES = [
  "DATABASE_URL",
  "PROCURETRACK_SECRET_KEY",
  "PROCURETRACK_ADMIN_EMAILS",
  "PROCURETRACK_TEAM_LEAD_EMAIL",
  "PROCURETRACK_TECHNICAL_APPROVER_EMAIL",
  "PROCURETRACK_SMTP_HOST",
  "PROCURETRACK_SMTP_PORT",
  "PROCURETRACK_SMTP_USERNAME",
  "PROCURETRACK_SMTP_PASSWORD",
  "PROCURETRACK_SMTP_FROM",
  "PROCURETRACK_SMTP_SECURITY",
];

export class ProcureTrackContainer extends DurableObject {
  starting;

  async fetch(request) {
    this.starting ??= this.startAndWaitForHealth().finally(() => {
      this.starting = undefined;
    });
    await this.starting;

    const upstream = new URL(request.url);
    const originalHost = upstream.host;
    const originalProto = upstream.protocol.replace(":", "");
    upstream.protocol = "http:";
    upstream.host = "container";
    const forwarded = new Request(upstream, request);
    forwarded.headers.delete("host");
    forwarded.headers.set("x-forwarded-host", originalHost);
    forwarded.headers.set("x-forwarded-proto", originalProto);
    forwarded.headers.set("x-forwarded-for", request.headers.get("cf-connecting-ip") || "");
    return this.ctx.container.getTcpPort(8080).fetch(forwarded);
  }

  async startAndWaitForHealth() {
    const container = this.ctx.container;
    await container.setInactivityTimeout(10 * 60 * 1000);
    if (!container.running) {
      const env = {
        PROCURETRACK_CLOUDFLARE: this.env.PROCURETRACK_CLOUDFLARE,
        PROCURETRACK_ENV: this.env.PROCURETRACK_ENV,
        PROCURETRACK_HOST: this.env.PROCURETRACK_HOST,
        PROCURETRACK_PORT: this.env.PROCURETRACK_PORT,
        PROCURETRACK_DATA_DIR: this.env.PROCURETRACK_DATA_DIR,
        PROCURETRACK_ACCESS_TEAM_DOMAIN: this.env.PROCURETRACK_ACCESS_TEAM_DOMAIN,
        PROCURETRACK_ACCESS_AUD: this.env.PROCURETRACK_ACCESS_AUD,
      };
      for (const name of RUNTIME_SECRET_NAMES) {
        if (this.env[name]) env[name] = this.env[name];
      }
      if (!env.DATABASE_URL || !env.PROCURETRACK_SECRET_KEY ||
          !env.PROCURETRACK_ACCESS_TEAM_DOMAIN || !env.PROCURETRACK_ACCESS_AUD) {
        throw new Error("Set DATABASE_URL, PROCURETRACK_SECRET_KEY, and Cloudflare Access secrets/vars before starting.");
      }
      container.start({
        image: container.images.base,
        instance: "lite",
        enableInternet: true,
        env,
      });
    }

    const port = this.ctx.container.getTcpPort(8080);
    let lastError;
    for (let attempt = 0; attempt < 100; attempt++) {
      try {
        const response = await port.fetch("http://container/health", {
          signal: AbortSignal.timeout(1000),
        });
        await response.body?.cancel();
        if (response.ok) return;
        throw new Error(`Health check returned ${response.status}`);
      } catch (error) {
        lastError = error;
        await scheduler.wait(200);
      }
    }
    throw new Error("ProcureTrack container did not become healthy on port 8080", { cause: lastError });
  }
}

export default {
  fetch(request, env) {
    return env.PROCURETRACK_CONTAINER.getByName("procuretrack").fetch(request);
  },
};
