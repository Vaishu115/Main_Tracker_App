"""Prepare application modules and Flask assets for Cloudflare Workers."""

from pathlib import Path
from pprint import pformat
import shutil

ROOT = Path(__file__).resolve().parents[1]
ASSET_ROOT = ROOT / ".worker-assets"
PYTHON_MODULES = ROOT / "python_modules"

if ASSET_ROOT.exists():
    shutil.rmtree(ASSET_ROOT)

for folder in ("templates", "static"):
    shutil.copytree(ROOT / folder, ASSET_ROOT / folder)

template_sources = {
    path.relative_to(ROOT / "templates").as_posix(): path.read_text(encoding="utf-8")
    for path in (ROOT / "templates").rglob("*.html")
}
PYTHON_MODULES.mkdir(parents=True, exist_ok=True)
template_module = PYTHON_MODULES / "procuretrack_worker_templates.py"
template_module.write_text(
    "TEMPLATES = " + pformat(template_sources, sort_dicts=True) + "\n",
    encoding="utf-8",
)

# Python Workers bundle local imports from `python_modules/` at the project root.
# The Flask package lives beside that directory in the source tree, so stage it
# there before PyWrangler bundles the Worker.
app_modules = PYTHON_MODULES / "procuretrack"
if app_modules.exists():
    shutil.rmtree(app_modules)
shutil.copytree(ROOT / "procuretrack", app_modules)

print(f"Prepared Worker assets in {ASSET_ROOT}")
