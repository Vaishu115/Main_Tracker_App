"""Store received and inspection photos on procurement requests.

Revision ID: 0011_request_photos
Revises: 0010_vendor_documents_gst_status
Create Date: 2026-10-19
"""

import sqlalchemy as sa
from alembic import op


revision = "0011_request_photos"
down_revision = "0010_vendor_documents_gst_status"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "request_photos",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column(
            "ticket_id",
            sa.Integer(),
            sa.ForeignKey("procurement_requests.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("uploaded_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("filename", sa.String(255), nullable=False),
        sa.Column("content_type", sa.String(30), nullable=False),
        sa.Column("size_bytes", sa.Integer(), nullable=False),
        sa.Column("data", sa.LargeBinary(), nullable=False),
        sa.Column("uploaded_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_request_photos_ticket_id", "request_photos", ["ticket_id"])


def downgrade():
    raise RuntimeError(
        "Downgrading is not supported. Restore the pre-migration database backup instead."
    )
