"""Track payment installments and remaining balance per ticket.

Revision ID: 0012_ticket_payments
Revises: 0011_request_photos
Create Date: 2026-10-21
"""

import sqlalchemy as sa
from alembic import op


revision = "0012_ticket_payments"
down_revision = "0011_request_photos"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "ticket_payments",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column(
            "ticket_id",
            sa.Integer(),
            sa.ForeignKey("procurement_requests.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("amount", sa.Numeric(12, 2), nullable=False),
        sa.Column("paid_on", sa.Date(), nullable=False),
        sa.Column("method", sa.String(60), nullable=False),
        sa.Column("reference", sa.String(100)),
        sa.Column("notes", sa.Text()),
        sa.Column("recorded_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_ticket_payments_ticket_id", "ticket_payments", ["ticket_id"])


def downgrade():
    op.drop_index("ix_ticket_payments_ticket_id", table_name="ticket_payments")
    op.drop_table("ticket_payments")
