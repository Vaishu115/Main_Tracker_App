"""Store requisitions awaiting Team Lead approval before ticket creation.

Revision ID: 0009_team_lead_review
Revises: 0008_rfq_attachments
Create Date: 2026-10-15
"""

import sqlalchemy as sa
from alembic import op

revision = "0009_team_lead_review"
down_revision = "0008_rfq_attachments"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "team_lead_approval_requests",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("token_hash", sa.String(64), nullable=False, unique=True),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("items", sa.JSON(), nullable=False),
        sa.Column("requester_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("expires_at", sa.DateTime(), nullable=False),
        sa.Column("decision", sa.String(20), nullable=False, server_default="pending"),
        sa.Column("decided_at", sa.DateTime()),
        sa.Column("decision_comment", sa.Text()),
        sa.Column(
            "ticket_id",
            sa.String(20),
            sa.ForeignKey("procurement_requests.ticket_id"),
        ),
    )


def downgrade():
    raise RuntimeError(
        "Downgrading is not supported. Restore the pre-migration database backup instead."
    )
