"""Add vendor GST registration status and supporting documents.

Revision ID: 0010_vendor_documents_gst_status
Revises: 0009_team_lead_review
Create Date: 2026-10-16
"""

import sqlalchemy as sa
from alembic import op


revision = "0010_vendor_documents_gst_status"
down_revision = "0009_team_lead_review"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("vendors", sa.Column("gst_registered", sa.Boolean(), nullable=True))
    op.execute(
        "UPDATE vendors SET gst_registered = CASE "
        "WHEN gstin IS NULL OR gstin = '' THEN FALSE ELSE TRUE END"
    )
    with op.batch_alter_table("vendors") as batch_op:
        batch_op.alter_column("gst_registered", existing_type=sa.Boolean(), nullable=False)

    op.create_table(
        "vendor_documents",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("vendor_id", sa.Integer(), sa.ForeignKey("vendors.id", ondelete="CASCADE"), nullable=False),
        sa.Column("kind", sa.String(30), nullable=False),
        sa.Column("filename", sa.String(255), nullable=False),
        sa.Column("content_type", sa.String(100), nullable=False),
        sa.Column("size_bytes", sa.Integer(), nullable=False),
        sa.Column("data", sa.LargeBinary(), nullable=False),
        sa.UniqueConstraint("vendor_id", "kind", name="uq_vendor_document_kind"),
    )


def downgrade():
    op.drop_table("vendor_documents")
    with op.batch_alter_table("vendors") as batch_op:
        batch_op.drop_column("gst_registered")
