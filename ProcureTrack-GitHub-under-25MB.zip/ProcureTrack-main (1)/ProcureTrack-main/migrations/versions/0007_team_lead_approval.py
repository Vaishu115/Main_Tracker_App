"""Add optional Team Lead approval request flag.

Revision ID: 0007_team_lead_approval
Revises: 0006_v062_requisition_items
Create Date: 2026-10-14
"""

import sqlalchemy as sa
from alembic import op

revision = "0007_team_lead_approval"
down_revision = "0006_v062_requisition_items"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "procurement_requests",
        sa.Column("team_lead_approval", sa.Boolean(), nullable=False, server_default=sa.false()),
    )


def downgrade():
    raise RuntimeError(
        "Downgrading is not supported. Restore the pre-migration backup from the "
        "data folder's backups/ directory instead."
    )
