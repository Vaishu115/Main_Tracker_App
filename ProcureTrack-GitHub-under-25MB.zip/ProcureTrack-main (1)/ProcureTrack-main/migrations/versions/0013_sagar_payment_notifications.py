"""Add in-app notifications for payment requests.

Revision ID: 0013_sagar_payment_notifications
Revises: 0012_ticket_payments
Create Date: 2026-10-22
"""

import sqlalchemy as sa
from alembic import op


revision = "0013_sagar_payment_notifications"
down_revision = "0012_ticket_payments"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "user_notifications",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column(
            "recipient_id",
            sa.Integer(),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "ticket_id",
            sa.Integer(),
            sa.ForeignKey("procurement_requests.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("message", sa.String(length=300), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("read_at", sa.DateTime()),
    )
    op.create_index("ix_user_notifications_recipient_id", "user_notifications", ["recipient_id"])
    op.create_index("ix_user_notifications_ticket_id", "user_notifications", ["ticket_id"])


def downgrade():
    op.drop_index("ix_user_notifications_ticket_id", table_name="user_notifications")
    op.drop_index("ix_user_notifications_recipient_id", table_name="user_notifications")
    op.drop_table("user_notifications")
