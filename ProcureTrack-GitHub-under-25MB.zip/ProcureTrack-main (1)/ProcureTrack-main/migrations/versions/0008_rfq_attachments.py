"""Store RFQ supporting documents on procurement requests.

Revision ID: 0008_rfq_attachments
Revises: 0007_team_lead_approval
Create Date: 2026-10-14
"""

import sqlalchemy as sa
from alembic import op

revision = "0008_rfq_attachments"
down_revision = "0007_team_lead_approval"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "request_attachments",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column(
            "ticket_id",
            sa.Integer(),
            sa.ForeignKey("procurement_requests.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("uploaded_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("filename", sa.String(255), nullable=False),
        sa.Column("content_type", sa.String(100), nullable=False),
        sa.Column("size_bytes", sa.Integer(), nullable=False),
        sa.Column("data", sa.LargeBinary(), nullable=False),
        sa.Column("uploaded_at", sa.DateTime(), nullable=False),
    )
    op.create_index(
        "ix_request_attachments_ticket_id", "request_attachments", ["ticket_id"]
    )


def downgrade():
    raise RuntimeError(
        "Downgrading is not supported. Restore the pre-migration database backup instead."
    )
