# Deploy on Cloudflare Workers Free

This setup runs ProcureTrack's Flask app as a Cloudflare Python Worker. It uses no
Containers or Docker for deployment. PostgreSQL is hosted by a separate provider and
connected through Cloudflare Hyperdrive. The Cloudflare Workers and Hyperdrive free plans
have daily usage limits; see [Workers pricing](https://developers.cloudflare.com/workers/platform/pricing/)
and [Hyperdrive pricing](https://developers.cloudflare.com/hyperdrive/platform/pricing/).

## 1. Create PostgreSQL and Hyperdrive

1. Create the PostgreSQL database with a managed database provider. For example, on Neon,
   create a project and database in the Neon Console, then copy its **direct** connection
   string (not the pooled string). Supabase and other PostgreSQL providers also work if
   their database accepts connections from Cloudflare. The database is created at the
   database provider; Cloudflare Hyperdrive is a connection pool/proxy, not the database
   storage itself.
2. From **this directory** (`ProcureTrack-main`), log in to Cloudflare and create a
   Hyperdrive configuration using that database's direct TLS connection string:

   ```powershell
   npx wrangler hyperdrive create procuretrack-db --connection-string="postgresql://USER:PASSWORD@HOST:5432/DATABASE?sslmode=require" --caching-disabled
   ```

   Wrangler returns a Hyperdrive config ID. Put it in `wrangler.jsonc` in place of
   `REPLACE_WITH_HYPERDRIVE_CONFIG_ID`. Keep the connection string private; do not commit it
   or paste it into `wrangler.jsonc`.
3. Put the same direct PostgreSQL URL in the ignored local `.env` as `DATABASE_URL`, then
   from this directory install the Python dependencies and run the first schema migration:

   ```powershell
   uv sync
   uv run flask --app app db upgrade
   ```

   This creates the tables in the remote PostgreSQL database. The Worker deliberately does
   not run migrations automatically. Back up the database before future schema upgrades.
   Do not upload or point the Worker at `instance/procurement.db`; that is a local SQLite
   development database and is not used by this deployment.

## 2. Enable sign-in

Deployments use the free `workers.dev` hostname. In Cloudflare Workers & Pages, open the
Worker after deployment and enable Cloudflare Access for its `workers.dev` URL. Configure
One-time PIN and an allow policy for the staff email addresses. Copy the Access team domain
and application audience tag. See [Cloudflare Access for Workers](https://developers.cloudflare.com/workers/configuration/cloudflare-access/).

## 3. Add secrets

Run these from the project folder; Wrangler prompts for each value:

```powershell
npx wrangler secret put PROCURETRACK_SECRET_KEY
npx wrangler secret put PROCURETRACK_ACCESS_TEAM_DOMAIN
npx wrangler secret put PROCURETRACK_ACCESS_AUD
npx wrangler secret put PROCURETRACK_ADMIN_EMAILS
npx wrangler secret put PROCURETRACK_TEAM_LEAD_EMAIL
```

Generate the secret key with `python -c "import secrets; print(secrets.token_hex(32))"`.
For email notifications and approvals, also set `PROCURETRACK_SMTP_HOST`,
`PROCURETRACK_SMTP_PORT`, `PROCURETRACK_SMTP_USERNAME`, `PROCURETRACK_SMTP_PASSWORD`,
`PROCURETRACK_SMTP_FROM`, and `PROCURETRACK_SMTP_SECURITY`. Rohit's email can be added later
with `npx wrangler secret put PROCURETRACK_TECHNICAL_APPROVER_EMAIL`.

`DATABASE_URL` is not deployed as a Worker secret. The Worker reads the database credentials
from the Hyperdrive binding in `wrangler.jsonc`. Your local `.env` is never uploaded.

## 4. Install and deploy

Install Node.js/npm, Python 3.12 or newer, and `uv`. In the project directory run:

```powershell
npm install
uv sync
npx wrangler login
npm run deploy
```

Run these commands from the `ProcureTrack-main` directory, which contains
`wrangler.jsonc`, `package.json`, and `src/worker.py`.

The deploy script copies the Flask templates and static files into the Worker asset bucket,
then calls `uv run pywrangler deploy`. Open the deployed Worker URL from Cloudflare, enable
Access, and test sign-in with an allowed email. The first signed-in user is a Requester;
the email in `PROCURETRACK_ADMIN_EMAILS` becomes an Admin on first sign-in.

## Install on a phone

After deploying, open the ProcureTrack URL on the phone and sign in through Cloudflare Access.
On Android, use the browser menu and choose **Install app** or **Add to Home screen**. On
iPhone, open the link in Safari, tap **Share**, then **Add to Home Screen**. ProcureTrack needs
an internet connection; the service worker does not cache private requests or procurement data.

## 5. Limits and updates

The Workers Free plan includes 100,000 requests per day and Hyperdrive Free includes 100,000
database queries per day. The free Worker CPU limit is 10 ms per request. If the app exceeds
any free limit, requests or database operations can fail until the quota resets. See the
current [Workers pricing and limits](https://developers.cloudflare.com/workers/platform/pricing/)
and [Hyperdrive pricing](https://developers.cloudflare.com/hyperdrive/platform/pricing/).

For application changes, run `npm run deploy` again. For migration changes, put the direct
database URL in local `.env` and run `flask --app app db upgrade` first.
