# Direct Cloudflare deployment

> **Deprecated:** This older guide uses Containers and a paid Workers plan. Use the
> [Cloudflare Workers Free guide](CLOUDFLARE_WORKERS_FREE.md) for the current no-Container setup.

This is the deployment path for ProcureTrack. It runs the existing Flask app in a
Cloudflare Container, with PostgreSQL for persistent data and Cloudflare Access email
one-time codes for sign-in. It does not use Cloudflare Tunnel or Microsoft sign-in.

Cloudflare Containers require the Workers Paid plan. The container disk is temporary,
so the database must be external; logs go to Cloudflare and SMTP credentials are supplied
as Worker secrets when the container starts. See Cloudflare's [Containers overview](https://developers.cloudflare.com/containers/),
[deployment guide](https://developers.cloudflare.com/containers/guides/deploy/), and
[container secrets guide](https://developers.cloudflare.com/containers/examples/env-vars-and-secrets/).

## 1. Prepare the Cloudflare account

1. Put your domain on Cloudflare and use a custom hostname such as
   `procuretrack.ericrobotics.com` for the Worker.
2. Enable the Workers Paid plan. Install Node.js, npm, Docker Desktop (or a compatible
   Docker engine), and Wrangler (`npm install`).
3. Create a PostgreSQL database with a managed provider. Use its TLS connection URL; the
   app migrations create a new, empty database automatically on first start.
4. In Cloudflare Zero Trust, create an Access application for the app hostname. Enable
   **One-time PIN** as the identity provider and add an Allow policy limited to the
   ERIC staff email addresses or `@ericrobotics.com` domain. Access must protect the
   entire hostname, including `/login`; the application separately verifies Access's
   signed identity token.
5. In that Access application's setup page, copy the **Application Audience (AUD) tag**.
   Find your team domain under Zero Trust settings, e.g. `your-team.cloudflareaccess.com`.

## 2. Set Cloudflare secrets

From the project directory, log in once with `npx wrangler login`, then add secrets.
Wrangler prompts for each value; secrets are not committed to the project.

```powershell
npx wrangler secret put DATABASE_URL
npx wrangler secret put PROCURETRACK_SECRET_KEY
npx wrangler secret put PROCURETRACK_ACCESS_TEAM_DOMAIN
npx wrangler secret put PROCURETRACK_ACCESS_AUD
npx wrangler secret put PROCURETRACK_ADMIN_EMAILS
npx wrangler secret put PROCURETRACK_TEAM_LEAD_EMAIL
npx wrangler secret put PROCURETRACK_TECHNICAL_APPROVER_EMAIL
npx wrangler secret put PROCURETRACK_SMTP_HOST
npx wrangler secret put PROCURETRACK_SMTP_PORT
npx wrangler secret put PROCURETRACK_SMTP_USERNAME
npx wrangler secret put PROCURETRACK_SMTP_PASSWORD
npx wrangler secret put PROCURETRACK_SMTP_FROM
npx wrangler secret put PROCURETRACK_SMTP_SECURITY
```

Values:

- `DATABASE_URL`: PostgreSQL TLS URL from your database provider (for example a
  `postgresql://...` connection string).
- `PROCURETRACK_SECRET_KEY`: a long random value. Generate one with
  `python -c "import secrets; print(secrets.token_hex(32))"`.
- `PROCURETRACK_ACCESS_TEAM_DOMAIN`: just the team domain, without `https://`.
- `PROCURETRACK_ACCESS_AUD`: the Access application's audience tag.
- `PROCURETRACK_TEAM_LEAD_EMAIL`: recipient for Team Lead notifications and approval requests.
- `PROCURETRACK_TECHNICAL_APPROVER_EMAIL`: Rohit's sign-in email; add it when available. Required only when an Engineering TL requests technical approval.
- `PROCURETRACK_ADMIN_EMAILS`: first administrator's email address. Separate multiple
  addresses with commas. New approved Access users are added as Requesters; listed
  administrator(s) are promoted on their first sign-in.
- SMTP: fill these from your SMTP provider. Use port `465` with `ssl`, or `587` with
  `starttls`; set `PROCURETRACK_SMTP_SECURITY` accordingly. Leaving host/from blank
  disables mail. Container internet access is enabled for PostgreSQL, Access key
  retrieval, and SMTP connections.

Cloudflare containers receive secrets when they start. The container stops after ten
minutes without traffic; after changing secrets, allow it to go idle so its next start
receives the new values. Redeploy code changes with Wrangler.

## 3. Deploy

```powershell
npm install
npx wrangler deploy
```

The first deployment builds the Docker image and provisions the container and may take a
few minutes. In the Cloudflare dashboard, attach the custom hostname to the Worker, then
confirm its Access application protects that hostname. Visit the hostname and test an
approved email with the one-time code. The first login creates the ProcureTrack user;
`PROCURETRACK_ADMIN_EMAILS` makes the designated account an admin.

The app exposes `/health` for an availability check. Keep it behind the same Access
policy. The database is the persistent source of truth. Configure automated backups in
the PostgreSQL provider and periodically test a restore; local SQLite backup commands do
not back up PostgreSQL.

## 4. Email approval

When an engineer selects **Team Lead Approval: No**, ProcureTrack creates the case immediately
and sends the Team Lead a notification only. Selecting **Yes** sends a one-time review link;
approval from that page creates the procurement case. The link expires after seven days. Ensure
the Team Lead is allowed by the Cloudflare Access policy.
For Engineering requests, the Team Lead can instead request technical approval. ProcureTrack emails
the configured technical approver a sign-in link; that exact email must be allowed by Cloudflare
Access and must match the account signed into ProcureTrack. Configure
`PROCURETRACK_TECHNICAL_APPROVER_EMAIL` before using this option.
The existing approval stage also notifies active Approver users. SMTP is optional for
deployment but required for email delivery. SMTP failures are logged and no case is created.

## 5. Updates

Commit/push the code, then from this directory run `npx wrangler deploy` (or connect the
repository under Workers Builds and use `npx wrangler deploy` as its deploy command).
The app applies new Alembic migrations at container startup. Back up PostgreSQL before
deploying schema changes.

## Limits to plan for

- Workers Paid plan and an external PostgreSQL service are required.
- The container's local disk is ephemeral. Do not store uploaded files or durable data
  there. RFQ attachments are stored in PostgreSQL along with application records.
- This repository's deployment setup is prepared, but deployment itself requires your
  Cloudflare account, hostname, database URL, Access audience and SMTP credentials.
