"""Roles, the approval step and sign-in."""

import pytest

from helpers import (
    add_vendor,
    create_via,
    edit_form,
    fill_requisition,
    get_ticket,
    request_form,
    set_prices,
    set_stage,
    user_id,
)


def status(client, url, **data):
    return client.post(url, data=data).status_code


# ---- sign-in required ----


def test_pages_require_sign_in(app):
    client = app.test_client()
    response = client.get("/queue")
    assert response.status_code == 302
    assert "/login?next=/queue" in response.headers["Location"]
    assert client.get("/login").status_code == 200
    assert client.get("/static/css/style.css").status_code == 200
    assert client.post("/request", data={}).status_code == 302


def test_dev_login_and_logout(app):
    client = app.test_client()
    page = client.get("/login").get_data(as_text=True)
    assert "Chirag (Approver)" in page

    response = client.post(
        "/login/dev", data={"user_id": user_id(app, "approver"), "next": "/queue"}
    )
    assert response.headers["Location"] == "/queue"
    assert client.get("/queue").status_code == 200

    client.post("/logout")
    assert client.get("/queue").status_code == 302


def test_dev_login_refused_from_other_computers(app):
    client = app.test_client()
    remote = {"REMOTE_ADDR": "10.0.0.5"}
    page = client.get("/login", environ_base=remote).get_data(as_text=True)
    assert "Chirag" not in page
    assert "has not been set up" in page
    assert (
        client.post(
            "/login/dev", data={"user_id": user_id(app, "admin")}, environ_base=remote
        ).status_code
        == 403
    )


def test_open_redirect_blocked(app):
    client = app.test_client()
    response = client.post(
        "/login/dev", data={"user_id": user_id(app, "admin"), "next": "//evil.example"}
    )
    assert response.headers["Location"] == "/"


def test_disabled_user_is_signed_out(app, client_as):
    from procuretrack.extensions import db
    from procuretrack.models import User

    client = client_as("requester")
    with app.app_context():
        db.session.get(User, user_id(app, "requester")).active = False
        db.session.commit()
    assert client.get("/queue").status_code == 302


# ---- requesters ----


def test_requester_creates_and_edits_own_ticket_early(app, client_as):
    rahul = client_as("requester")
    ticket_id = create_via(rahul, app)
    ticket = get_ticket(app, ticket_id)
    assert ticket.created_by_id == user_id(app, "requester")
    assert ticket.history[0].actor_name == "Rahul"

    form = edit_form(app, ticket_id, item_description=["Changed"], priority="Low")
    assert rahul.post(f"/ticket/{ticket_id}/edit", data=form).status_code == 302
    assert get_ticket(app, ticket_id).items[0].description == "Changed"

    # someone else's ticket: no
    assert client_as("requester2").get(f"/ticket/{ticket_id}/edit").status_code == 403

    # once it's sent for approval: no more edits by the requester
    set_stage(app, ticket_id, "Approval Pending")
    assert rahul.get(f"/ticket/{ticket_id}/edit").status_code == 403


def test_requester_chooses_vendor_and_purchase_adds_prices(app, client, client_as):
    vendor_id = add_vendor(client, name="Pune Precision")
    rahul = client_as("requester")
    ticket_id = create_via(rahul, app, data=request_form(recommended_vendor_id=str(vendor_id)))
    ticket = get_ticket(app, ticket_id)
    assert ticket.recommended_vendor.name == "Pune Precision"
    assert ticket.missing_for_approval == ["prices and GST for every item"]

    # prices are for the purchase team only
    item_id = ticket.items[0].id
    prices = {f"price-{item_id}": "8500", f"gst-{item_id}": "18"}
    assert rahul.post(f"/ticket/{ticket_id}/prices", data=prices).status_code == 403
    assert 'name="price-' not in rahul.get(f"/ticket/{ticket_id}").get_data(as_text=True)

    priya = client_as("purchase")
    set_prices(priya, app, ticket_id, price="8500", gst="18")
    ticket = get_ticket(app, ticket_id)
    assert ticket.requisition_complete
    assert ticket.estimate.total == 20060  # 2 x 8500 + 18%
    assert ticket.history[0].event_type == "REQUISITION"
    assert ticket.history[0].comment == "RTX A1000 GPU: — → ₹8,500.00 + 18% GST"


def test_requester_adds_a_new_vendor_from_the_request_form(app, client_as):
    rahul = client_as("requester")
    new_vendor = {"recommended_vendor_id": "new", "new_vendor_name": "Fresh Motors"}

    # Indian vendors need a state; the typed values are kept on error
    response = rahul.post("/request", data=request_form(**new_vendor))
    body = response.get_data(as_text=True)
    assert response.status_code == 400
    assert "State is required." in body and 'value="Fresh Motors"' in body

    ticket_id = create_via(
        rahul,
        app,
        data=request_form(
            **new_vendor,
            new_vendor_country="India",
            new_vendor_state_code="27",
            new_vendor_city="Pune",
            new_vendor_phone="98200 00000",
        ),
    )
    ticket = get_ticket(app, ticket_id)
    assert ticket.recommended_vendor.name == "Fresh Motors"
    assert ticket.recommended_vendor.state_code == "27"
    assert ticket.recommended_vendor.notes == "Added by Rahul"
    assert "New vendor added to the Vendors list: Fresh Motors" in ticket.history[0].comment

    # the vendor is now in everyone's list; names stay unique
    response = rahul.post("/request", data=request_form(**new_vendor, new_vendor_state_code="27"))
    assert "A vendor with this name already exists." in response.get_data(as_text=True)


def test_purchase_can_change_vendor_until_approval_then_it_is_locked(app, client_as):
    priya = client_as("purchase")
    ticket_id = create_via(client_as("requester"), app)
    fill_requisition(priya, ticket_id)
    set_stage(app, ticket_id, "Approval Pending")

    # at Approval Pending: the requester can't edit, purchase still can
    other = add_vendor(priya, name="Mumbai Motors", state="27")
    assert client_as("requester").get(f"/ticket/{ticket_id}/edit").status_code == 403
    priya.post(
        f"/ticket/{ticket_id}/edit",
        data=edit_form(app, ticket_id, recommended_vendor_id=str(other)),
    )
    ticket = get_ticket(app, ticket_id)
    assert ticket.recommended_vendor_id == other
    assert ticket.history[0].comment == "Vendor: Robu → Mumbai Motors"

    # after approval the vendor, items and prices are locked, even for purchase
    client_as("approver").post(f"/ticket/{ticket_id}/advance", data={})
    form = edit_form(app, ticket_id, recommended_vendor_id="", quantity=["99"], priority="Low")
    assert priya.post(f"/ticket/{ticket_id}/edit", data=form).status_code == 302
    ticket = get_ticket(app, ticket_id)
    assert (ticket.recommended_vendor_id, ticket.items[0].quantity) == (other, 2)
    assert ticket.priority == "Low"  # general details can still change
    item_id = ticket.items[0].id
    prices = {f"price-{item_id}": "1", f"gst-{item_id}": "0"}
    assert priya.post(f"/ticket/{ticket_id}/prices", data=prices).status_code == 403


def test_requester_cannot_run_the_process(app, client_as):
    rahul = client_as("requester")
    ticket_id = create_via(rahul, app)
    for action in ["advance", "send-back", "hold", "reopen", "archive", "restore", "delete"]:
        assert status(rahul, f"/ticket/{ticket_id}/{action}", comment="x") == 403, action
    assert status(rahul, f"/ticket/{ticket_id}/tracking") == 403
    assert rahul.get("/users/").status_code == 403
    assert "Edit" in rahul.get(f"/ticket/{ticket_id}").get_data(as_text=True)
    assert "Advance to" not in rahul.get(f"/ticket/{ticket_id}").get_data(as_text=True)


def test_requester_can_cancel_own_ticket_before_approval(app, client_as):
    rahul = client_as("requester")
    ticket_id = create_via(rahul, app)
    assert status(client_as("requester2"), f"/ticket/{ticket_id}/cancel", comment="x") == 403
    assert status(rahul, f"/ticket/{ticket_id}/cancel", comment="Not needed") == 302
    assert get_ticket(app, ticket_id).state == "Cancelled"


# ---- approval ----


def test_purchase_sends_for_approval_but_cannot_approve(app, client_as):
    priya = client_as("purchase")
    ticket_id = create_via(client_as("requester"), app)
    set_stage(app, ticket_id, "Vendor Selected")

    page = priya.get(f"/ticket/{ticket_id}").get_data(as_text=True)
    assert "Send for Approval" in page

    # the requisition (vendor + prices) must be filled in first
    response = priya.post(f"/ticket/{ticket_id}/advance", data={}, follow_redirects=True)
    assert "Fill in the vendor and prices and GST for every item" in response.get_data(as_text=True)
    assert get_ticket(app, ticket_id).status == "Vendor Selected"
    fill_requisition(priya, ticket_id)

    priya.post(f"/ticket/{ticket_id}/advance", data={})
    assert get_ticket(app, ticket_id).status == "Approval Pending"

    assert status(priya, f"/ticket/{ticket_id}/advance") == 403
    assert get_ticket(app, ticket_id).status == "Approval Pending"
    page = priya.get(f"/ticket/{ticket_id}").get_data(as_text=True)
    assert "Waiting for approval by <b>Chirag</b>" in page

    # purchase can pull it back; that's not a rejection
    priya.post(f"/ticket/{ticket_id}/send-back", data={"comment": "Wrong vendor quote attached"})
    ticket = get_ticket(app, ticket_id)
    assert ticket.status == "Vendor Selected"
    assert ticket.history[0].event_type == "SENT_BACK"


def test_approver_approves(app, client_as):
    chirag = client_as("approver")
    ticket_id = create_via(client_as("requester"), app)
    set_stage(app, ticket_id, "Approval Pending")

    assert "Your approval is needed" in chirag.get(f"/ticket/{ticket_id}").get_data(as_text=True)
    assert f"/ticket/{ticket_id}" in chirag.get("/").get_data(as_text=True)  # dashboard list

    response = chirag.post(
        f"/ticket/{ticket_id}/advance", data={"comment": "OK, go ahead"}, follow_redirects=True
    )
    assert "Approved. Moved to PO Released." in response.get_data(as_text=True)

    ticket = get_ticket(app, ticket_id)
    assert ticket.status == "PO Released"
    event = ticket.history[0]
    assert (event.event_type, event.actor_name, event.comment) == (
        "APPROVED",
        "Chirag",
        "OK, go ahead",
    )

    # the approver doesn't run the rest of the process
    assert status(chirag, f"/ticket/{ticket_id}/advance") == 403
    assert status(chirag, f"/ticket/{ticket_id}/tracking") == 403


def test_approver_rejects_with_reason(app, client_as):
    chirag = client_as("approver")
    ticket_id = create_via(client_as("requester"), app)
    set_stage(app, ticket_id, "Approval Pending")

    chirag.post(f"/ticket/{ticket_id}/send-back", data={"comment": ""})
    assert get_ticket(app, ticket_id).status == "Approval Pending"

    chirag.post(f"/ticket/{ticket_id}/send-back", data={"comment": "Get one more quotation"})
    ticket = get_ticket(app, ticket_id)
    assert ticket.status == "Vendor Selected"
    assert (ticket.history[0].event_type, ticket.history[0].actor_name) == ("REJECTED", "Chirag")


def test_approver_can_approve_own_ticket_and_it_is_marked(app, client_as):
    chirag = client_as("approver")
    ticket_id = create_via(chirag, app)
    set_stage(app, ticket_id, "Approval Pending")
    chirag.post(f"/ticket/{ticket_id}/advance", data={"comment": "Urgent for demo"})
    ticket = get_ticket(app, ticket_id)
    assert ticket.status == "PO Released"
    assert ticket.history[0].comment == "Self-approved. Urgent for demo"


def test_self_approval_can_be_switched_off(app, client_as):
    app.config["ALLOW_SELF_APPROVAL"] = False
    chirag = client_as("approver")
    ticket_id = create_via(chirag, app)
    set_stage(app, ticket_id, "Approval Pending")
    assert status(chirag, f"/ticket/{ticket_id}/advance") == 403
    assert "another approver has to approve it" in chirag.get(f"/ticket/{ticket_id}").get_data(
        as_text=True
    )


def test_admin_is_not_an_approver(app, client):
    ticket_id = create_via(client, app)
    set_stage(app, ticket_id, "Approval Pending")
    assert status(client, f"/ticket/{ticket_id}/advance") == 403


# ---- users page ----


def test_non_admins_cannot_manage_users_or_delete(app, client_as):
    priya = client_as("purchase")
    assert priya.get("/users/").status_code == 403
    ticket_id = create_via(priya, app)
    assert status(priya, f"/ticket/{ticket_id}/delete") == 403


def test_admin_adds_and_updates_users(app, client):
    response = client.post(
        "/users/", data={"email": "New.Person@Eric.test", "name": "New Person", "role": "approver"}
    )
    assert response.status_code == 302
    assert (
        client.post(
            "/users/", data={"email": "new.person@eric.test", "name": "Dup", "role": "requester"}
        ).status_code
        == 400
    )
    assert (
        client.post(
            "/users/", data={"email": "not-an-email", "name": "X", "role": "requester"}
        ).status_code
        == 400
    )

    from procuretrack.extensions import db
    from procuretrack.models import User

    with app.app_context():
        user = db.session.scalar(db.select(User).where(User.email == "new.person@eric.test"))
        assert user.role == "approver"
        uid = user.id

    client.post(f"/users/{uid}", data={"name": "Renamed", "role": "purchase", "active": "on"})
    with app.app_context():
        user = db.session.get(User, uid)
        assert (user.name, user.role, user.is_admin, user.active) == (
            "Renamed",
            "purchase",
            False,
            True,
        )


def test_admin_cannot_lock_themselves_out(app, client):
    admin_id = user_id(app, "admin")
    response = client.post(
        f"/users/{admin_id}",
        data={"name": "Sagar", "role": "purchase", "active": "on"},
        follow_redirects=True,
    )
    assert "There must be at least one active admin." in response.get_data(as_text=True)

    from procuretrack.extensions import db
    from procuretrack.models import User

    with app.app_context():
        assert db.session.get(User, admin_id).is_admin


# ---- Microsoft 365 sign-in (Microsoft's side is simulated) ----

TENANT = "11111111-2222-3333-4444-555555555555"


class FakeMsal:
    claims = {}

    def __init__(self, *args, **kwargs):
        pass

    def initiate_auth_code_flow(self, scopes, redirect_uri):
        return {
            "auth_uri": "https://login.microsoftonline.com/authorize?state=abc",
            "state": "abc",
            "redirect_uri": redirect_uri,
        }

    def acquire_token_by_auth_code_flow(self, flow, args):
        if args.get("state") != flow["state"]:
            raise ValueError("state mismatch")
        return {"id_token_claims": FakeMsal.claims}


@pytest.fixture
def ms_client(app, monkeypatch):
    import procuretrack.views.auth as auth

    monkeypatch.setattr(auth.msal, "ConfidentialClientApplication", FakeMsal)
    app.config.update(
        AUTH_MODE="microsoft", MS_TENANT_ID=TENANT, MS_CLIENT_ID="client", MS_CLIENT_SECRET="secret"
    )
    return app.test_client()


def ms_sign_in(client, **claims):
    FakeMsal.claims = {
        "tid": TENANT,
        "oid": "oid-1",
        "preferred_username": "new.hire@eric.test",
        "name": "New Hire",
        **claims,
    }
    start = client.get("/auth/microsoft?next=/queue")
    assert start.headers["Location"].startswith("https://login.microsoftonline.com/")
    return client.get("/auth/callback?code=xyz&state=abc")


def test_microsoft_first_sign_in_creates_requester(app, ms_client):
    assert "Sign in with Microsoft 365" in ms_client.get("/login").get_data(as_text=True)
    assert ms_client.post("/login/dev", data={"user_id": 1}).status_code == 403

    response = ms_sign_in(ms_client)
    assert response.headers["Location"] == "/queue"
    assert ms_client.get("/queue").status_code == 200

    from procuretrack.extensions import db
    from procuretrack.models import User

    with app.app_context():
        user = db.session.scalar(db.select(User).where(User.email == "new.hire@eric.test"))
        assert (user.role, user.ms_oid, user.is_admin) == ("requester", "oid-1", False)


def test_microsoft_links_pre_registered_user_and_keeps_role(app, ms_client):
    ms_sign_in(ms_client, preferred_username="Approver@Eric.test", oid="oid-chirag")
    from procuretrack.extensions import db
    from procuretrack.models import User

    with app.app_context():
        user = db.session.get(User, user_id(app, "approver"))
        assert (user.ms_oid, user.role) == ("oid-chirag", "approver")


def test_microsoft_rejects_other_tenants_and_bad_state(app, ms_client):
    ms_sign_in(ms_client, tid="someone-elses-tenant")
    assert ms_client.get("/queue").status_code == 302

    ms_client.get("/auth/microsoft")
    ms_client.get("/auth/callback?code=xyz&state=forged")
    assert ms_client.get("/queue").status_code == 302


def test_microsoft_admin_emails_bootstrap_first_admin(app, ms_client):
    app.config["ADMIN_EMAILS"] = {"boss@eric.test"}
    ms_sign_in(ms_client, preferred_username="boss@eric.test", oid="oid-boss")
    assert ms_client.get("/users/").status_code == 200


# ---- production mode ----


def test_production_turns_off_test_sign_in_and_uses_secure_cookies(tmp_path, monkeypatch):
    from helpers import make_app

    monkeypatch.setenv("PROCURETRACK_ENV", "production")
    for name in ("TENANT_ID", "CLIENT_ID", "CLIENT_SECRET"):
        monkeypatch.delenv(f"PROCURETRACK_MS_{name}", raising=False)
    from procuretrack.config import auth_settings

    app = make_app(tmp_path, **auth_settings())
    assert app.config["AUTH_MODE"] == "none"
    assert app.config["SESSION_COOKIE_SECURE"] is True

    client = app.test_client()
    page = client.get("/login").get_data(as_text=True)  # even from this computer
    assert "has not been set up" in page and "Sign in as" not in page
    assert client.post("/login/dev", data={"user_id": 1}).status_code == 403

    # links are https behind the proxy
    response = client.get(
        "/queue", headers={"X-Forwarded-Proto": "https", "X-Forwarded-Host": "pt.eric.test"}
    )
    assert response.headers["Location"].startswith("/login")


def test_health_check_needs_no_sign_in(app):
    response = app.test_client().get("/health")
    assert response.status_code == 200
    assert response.get_json()["status"] == "ok"


def test_send_for_approval_explains_what_is_missing(app, client_as):
    priya = client_as("purchase")
    ticket_id = create_via(client_as("requester"), app)
    set_stage(app, ticket_id, "Vendor Selected")
    page = priya.get(f"/ticket/{ticket_id}").get_data(as_text=True)
    assert "Can't send for approval yet." in page
    assert "Still missing: the vendor and prices and GST for every item." in page


def test_microsoft_redirect_uses_https_behind_proxy(app, ms_client, monkeypatch):
    from werkzeug.middleware.proxy_fix import ProxyFix

    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)  # as in production
    seen = {}

    def initiate(self, scopes, redirect_uri):
        seen["redirect_uri"] = redirect_uri
        return {"auth_uri": "https://login.microsoftonline.com/x", "state": "s"}

    monkeypatch.setattr(FakeMsal, "initiate_auth_code_flow", initiate)
    ms_client.get(
        "/auth/microsoft",
        headers={"X-Forwarded-Proto": "https", "X-Forwarded-Host": "procuretrack.ericrobotics.com"},
    )
    assert seen["redirect_uri"] == "https://procuretrack.ericrobotics.com/auth/callback"


def test_microsoft_misconfiguration_shows_a_message(app, ms_client, monkeypatch):
    def broken(self, scopes, redirect_uri):
        raise ValueError("Unable to get authority configuration")

    monkeypatch.setattr(FakeMsal, "initiate_auth_code_flow", broken)
    response = ms_client.get("/auth/microsoft", follow_redirects=True)
    assert response.status_code == 200
    assert "Microsoft sign-in isn" in response.get_data(as_text=True)
