"""The purchase requisition: vendor + items + prices, approval, and the printed forms."""

from datetime import date

from procuretrack.extensions import db
from procuretrack.models import User

from helpers import (
    VALID_REQUEST,
    create_via,
    fill_requisition,
    get_ticket,
    set_stage,
    user_id,
)


def setup_company(client):
    client.post(
        "/settings/",
        data={
            "name": "ERIC Robotics Private Limited",
            "address": "17/8 MIDC Pimpri Chinchwad Pune, Maharashtra-411019 India",
            "state_code": "27",
            "plant": "ERIC Robotics, MIDC Chinchwad",
            "po_prefix": "ERIC/PO",
        },
    )


def send_and_approve(app, client_as, ticket_id):
    priya = client_as("purchase")
    set_stage(app, ticket_id, "Vendor Selected")
    priya.post(f"/ticket/{ticket_id}/advance", data={})
    client_as("approver").post(f"/ticket/{ticket_id}/advance", data={"comment": "OK"})
    assert get_ticket(app, ticket_id).status == "PO Released"


def new_po(client, vendor_id, ticket_pk=None):
    data = {"vendor_id": vendor_id}
    if ticket_pk:
        data["ticket"] = ticket_pk
    location = client.post("/pos/new", data=data).headers["Location"]
    return int(location.split("/pos/")[1].split("?")[0])


def two_item_ticket(client, app):
    return create_via(
        client,
        app,
        data={
            **VALID_REQUEST,
            "item_id": ["", ""],
            "item_description": ["BLDC Motor 24V 200W", "Motor driver"],
            "item_quantity": ["2", "2"],
            "item_unit": ["Nos", "Nos"],
        },
    )


def test_prices_validation(app, client):
    ticket_id = create_via(client, app)
    item_id = get_ticket(app, ticket_id).items[0].id
    response = client.post(
        f"/ticket/{ticket_id}/prices",
        data={f"price-{item_id}": "abc", f"gst-{item_id}": "50"},
        follow_redirects=True,
    )
    body = response.get_data(as_text=True)
    assert "Price of item 1 must be a number." in body
    assert "GST of item 1 must be between 0 and 40." in body
    assert get_ticket(app, ticket_id).items[0].est_unit_price is None


def test_estimate_adds_up_all_items(app, client):
    ticket_id = two_item_ticket(client, app)
    fill_requisition(client, ticket_id, price="1000.00", gst="18")
    ticket = get_ticket(app, ticket_id)
    assert ticket.requisition_complete
    assert ticket.estimate.total == 4720  # 4 x 1000 + 18%
    page = client.get(f"/ticket/{ticket_id}").get_data(as_text=True)
    assert "₹4,720.00" in page


def test_approver_sees_estimate(app, client, client_as):
    ticket_id = create_via(client, app, quantity="1")
    fill_requisition(client, ticket_id, price="318370.00", gst="18")
    set_stage(app, ticket_id, "Approval Pending")
    page = client_as("approver").get(f"/ticket/{ticket_id}").get_data(as_text=True)
    assert "Estimated cost: <b>₹3,75,676.60</b>" in page  # the figure on ERIC's sample form
    assert "View requisition form" in page


def test_printed_requisition_matches_erics_form(app, client, client_as):
    setup_company(client)
    with app.app_context():
        db.session.get(User, user_id(app, "requester")).department = "Engineering"
        db.session.commit()

    rahul = client_as("requester")
    ticket_id = create_via(
        rahul,
        app,
        item="GAPL-BTO-MIC-785-Ryzen9648",
        description="Compact fanless system",
        quantity="1",
    )
    fill_requisition(client, ticket_id, price="318370.00", gst="18")

    before = client.get(f"/ticket/{ticket_id}/requisition/print").get_data(as_text=True)
    assert "PURCHASE REQUISITION FORM" in before
    assert "NOT APPROVED" in before

    send_and_approve(app, client_as, ticket_id)
    form = client.get(f"/ticket/{ticket_id}/requisition/print").get_data(as_text=True)
    assert "NOT APPROVED" not in form
    assert f"Date: {date.today():%d-%m-%Y}" in form
    # the engineer who raised it is the requisitioner
    assert "Name: Rahul" in form and "Department: Engineering" in form
    assert "Plant: ERIC Robotics, MIDC Chinchwad" in form
    assert "V-name: Robu" in form
    assert "Est Cost: ₹3,75,676.60" in form
    assert "GAPL-BTO-MIC-785-Ryzen9648" in form and "(Compact fanless system)" in form
    assert "eric_logo_print.png" in form
    # digital signatures: requisitioner and Director (approver)
    assert "<b>Rahul</b><br>Raised in ProcureTrack" in form
    assert "<b>Chirag</b><br>Approved in ProcureTrack" in form


def test_printed_requisition_lists_every_item(app, client):
    ticket_id = two_item_ticket(client, app)
    fill_requisition(client, ticket_id, price="1000.00", gst="18")
    form = client.get(f"/ticket/{ticket_id}/requisition/print").get_data(as_text=True)
    assert "BLDC Motor 24V 200W" in form and "Motor driver" in form
    assert form.count("GST @18%") == 2
    assert "Est Cost: ₹4,720.00" in form


def test_last_purchase_of_same_item_is_shown(app, client, client_as):
    setup_company(client)
    first = create_via(client, app, item="Lidar", quantity="2")
    vendor_id = fill_requisition(client, first, price="5000.00")
    send_and_approve(app, client_as, first)

    po_id = new_po(client, vendor_id)
    client.post(
        f"/pos/{po_id}/lines",
        data={
            "item_id": get_ticket(app, first).items[0].id,
            "quantity": "2",
            "unit_price": "4800",
            "gst_rate": "18",
        },
    )
    client.post(f"/pos/{po_id}/issue")

    second = create_via(client, app, item="lidar ")  # same item, different case/space
    form = client.get(f"/ticket/{second}/requisition/print").get_data(as_text=True)
    assert f"Last Purchase Date: {date.today():%d-%m-%Y}" in form
    assert "Last PO Qty/Rate: 2 Nos @ ₹4,800.00" in form


def test_po_from_ticket_uses_recommended_vendor_and_approved_prices(app, client, client_as):
    setup_company(client)
    ticket_id = two_item_ticket(client, app)
    vendor_id = fill_requisition(client, ticket_id, price="100.00", gst="18")
    send_and_approve(app, client_as, ticket_id)
    pk = get_ticket(app, ticket_id).id

    page = client.get(f"/pos/new?ticket={pk}").get_data(as_text=True)
    assert f'<option value="{vendor_id}" selected>' in page

    po_id = new_po(client, vendor_id, pk)
    detail = client.get(f"/pos/{po_id}?add={pk}").get_data(as_text=True)
    assert 'data-price="100.00"' in detail  # add-one-item form pre-fills the approved estimate
    assert f'<option value="{pk}" selected>' in detail  # "add all items" pre-selects the ticket

    client.post(f"/pos/{po_id}/add-ticket", data={"ticket_id": pk})
    client.post(f"/pos/{po_id}/issue")
    printed = client.get(f"/pos/{po_id}/print").get_data(as_text=True)
    assert "PURCHASE ORDER" in printed
    assert f"PO Date: {date.today():%d-%m-%Y}" in printed
    assert "Grand Total" in printed and "₹472.00" in printed  # 4 x 100 + 18%
    assert "Plant: ERIC Robotics, MIDC Chinchwad" in printed
    assert printed.count("Approved PROC-") == 1  # one Director approval for the ticket

    ticket = get_ticket(app, ticket_id)
    assert not ticket.can_be_ordered
    event = ticket.history[0]
    assert event.event_type == "PO_ISSUED"
    assert event.comment.splitlines()[1:] == [
        "BLDC Motor 24V 200W: 2 Nos at ₹100.00 + GST 18%",
        "Motor driver: 2 Nos at ₹100.00 + GST 18%",
    ]


def test_user_department_is_saved(app, client):
    uid = user_id(app, "purchase")
    client.post(
        f"/users/{uid}",
        data={"name": "Priya", "role": "purchase", "department": "Purchase", "active": "on"},
    )
    with app.app_context():
        assert db.session.get(User, uid).department == "Purchase"
