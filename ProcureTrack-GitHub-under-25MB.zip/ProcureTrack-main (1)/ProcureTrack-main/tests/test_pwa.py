def test_manifest_is_available_without_sign_in(app):
    response = app.test_client().get("/manifest.webmanifest")

    assert response.status_code == 200
    manifest = response.get_json()
    assert manifest["name"] == "ProcureTrack | ERIC Robotics"
    assert manifest["start_url"] == "/"
    assert manifest["scope"] == "/"
    assert {icon["sizes"] for icon in manifest["icons"]} == {"192x192", "512x512"}


def test_service_worker_is_available_with_root_scope(app):
    response = app.test_client().get("/service-worker.js")

    assert response.status_code == 200
    assert response.mimetype == "application/javascript"
    assert response.headers["Service-Worker-Allowed"] == "/"
    script = response.get_data(as_text=True)
    assert "skipWaiting" in script
    assert "fetch(event.request)" in script
    assert "caches" not in script


def test_home_screen_icons_are_served(app):
    client = app.test_client()

    for filename in ("procuretrack-180.png", "procuretrack-192.png", "procuretrack-512.png"):
        response = client.get(f"/static/assets/{filename}")
        assert response.status_code == 200
        assert response.mimetype == "image/png"
