# ProcureTrack

Internal procurement tracking tool for ERIC Robotics. Tracks each engineering
requirement from *Requirement Raised* through RFQ, approval, PO, payment and
delivery to *Closed*, with a full activity timeline.

This README is for installing and running it on one PC. **Deploy to Cloudflare Workers Free:**
[docs/CLOUDFLARE_WORKERS_FREE.md](docs/CLOUDFLARE_WORKERS_FREE.md). Legacy VM/Tunnel notes:
[docs/DEPLOYMENT.md](docs/DEPLOYMENT.md). **Developers:** start with
[docs/DEVELOPER_GUIDE.md](docs/DEVELOPER_GUIDE.md). Changes per version: [versionhistory.md](versionhistory.md).

## Setup (once per machine)

Needs Python 3.12 or newer.

```powershell
cd PT_V0_3
python -m venv .venv
.\.venv\Scripts\python -m pip install -r requirements-app.txt
```

## Running

**Normal use** (production server):

```powershell
.\.venv\Scripts\python app.py
```

or double-click `scripts\start.bat`. Then open http://127.0.0.1:5000.

**While developing** (auto-reloads when you edit code, shows error details):

```powershell
.\.venv\Scripts\flask --app app run --debug
```

Never use `--debug` on a machine other people can reach: the debugger lets anyone run code on it.

## Sign-in and roles

Everyone has to sign in. What they can do depends on their role:

| Role | Can do |
|---|---|
| **Requester** (default) | Raise tickets (choose the vendor, list the items), view all tickets, edit or cancel their own ticket until it is sent for approval |
| **Purchase team** | Add prices per item, change the vendor or items until approval, move tickets through the stages, send for approval, hold, send back, cancel, reopen, archive; manage vendors, projects and purchase orders; update payment / delivery |
| **Approver** | Approve or reject tickets at *Approval Pending*. Nobody else can. Approving your own ticket is allowed and shows as "Self-approved" |
| **Admin** (extra tick box) | Purchase team rights + Users and Settings pages + permanent delete. Doesn't include approving |

### Purchase orders: first steps

1. An admin fills in **Settings**: company name, address, **state** (decides CGST+SGST vs IGST),
   GSTIN, plant and the PO number prefix, and sets each person's **department** on the Users page.
   POs can't be issued until the company details are done.
2. The purchase team adds **Vendors** and **Projects**.
3. An engineer raises a ticket: the **vendor** they recommend and one or more **items**
   (quantity and unit each). A ticket is one Purchase Requisition Form. A vendor that isn't
   in the list can be added from the form ("+ Add a new vendor").
4. The purchase team enters the **price and GST % for each item** from the quotation (and can
   change the vendor or items), then sends it for approval. The approver sees the estimated
   total, and the ticket page prints the **Purchase Requisition Form** in ERIC's format.
   After approval the vendor, items and prices are locked.
5. Once a ticket is approved, its page shows **New PO for this ticket**. On the draft PO,
   **Add all items of a ticket** adds everything still to order at the approved prices, or
   add items one by one. A PO can take items from several tickets, and an item's quantity can
   be split across POs to different vendors.
6. **Issue** the PO to number and lock it, then **Print / PDF** to send it to the vendor.

Admins change roles on the **Users** page (sidebar).

### First admin

Create yourself as the first admin once, in a terminal:

```powershell
.\.venv\Scripts\flask --app app add-user --email you@yourcompany.com --name "Your Name" --role purchase --admin
```

Use the address people sign in to Microsoft 365 with. After that, add everyone else on the Users page.

### Before Microsoft 365 is configured (testing)

The login page shows a **"Sign in as"** list so you can try each role. It only works when the
browser is on the same computer as the server (http://127.0.0.1:5000). From any other computer
the page says sign-in isn't set up. Don't put the app behind a reverse proxy while in this mode.

### Turning on Microsoft 365 sign-in

Ask your Microsoft 365 admin to register an app in the **Microsoft Entra admin center**:

1. *App registrations → New registration*. Name: `ProcureTrack`.
   Supported account types: **Accounts in this organizational directory only**.
2. Redirect URI: platform **Web**, `https://<address people use to open ProcureTrack>/auth/callback`.
   Microsoft only accepts **https** addresses here (plain `http://` works only for `localhost`),
   so ProcureTrack must be served over HTTPS before Microsoft sign-in can be switched on.
3. *Certificates & secrets → New client secret*. Copy the **Value**. Note its expiry date.
4. From *Overview*, copy the **Application (client) ID** and **Directory (tenant) ID**.
5. *API permissions*: the default **Microsoft Graph → User.Read** is enough.

Then add them to the `.env` file in the project folder (see [Configuration](#configuration))
and restart ProcureTrack:

```
PROCURETRACK_MS_TENANT_ID=<directory (tenant) id>
PROCURETRACK_MS_CLIENT_ID=<application (client) id>
PROCURETRACK_MS_CLIENT_SECRET=<client secret value>
```

When all three are set, the login page shows **Sign in with Microsoft 365** and the test list disappears.
Anyone in the company can sign in; first-timers become Requesters. Disable someone on the Users page
(or in Microsoft 365) to remove their access. Renew the client secret before it expires, or sign-in stops working.

## Where the data lives

Everything that isn't code goes in the **data folder**, kept outside the code folder so
updating or replacing the code can't touch it. On this installation it is **`C:\ProcureTrack\data`**
(set by `PROCURETRACK_DATA_DIR` in `.env`):

```
C:\ProcureTrack\data\
  procurement.db           the database
  backups\                 automatic and daily backups (newest 30 kept)
  logs\procuretrack.log    application log
  secret_key               generated on first run; keep it private
```

If `PROCURETRACK_DATA_DIR` isn't set, the app uses `<project>\instance`.
If the app ever shows no tickets, check the log for "No existing database found". It means
the app is looking in the wrong folder: check `.env`.

**Moving the data** (e.g. to the office server): stop the app, copy the whole data folder,
set `PROCURETRACK_DATA_DIR` in `.env` on the new machine, start the app.

**Upgrading from V0.3:** on first start, an old `procurement.db` next to `app.py` is copied
into the data folder, backed up, and converted to the new format. The old file is left untouched
and is no longer used. Once you've checked everything is there, you can delete it.

If `procurement.db` was committed to git before, remove it from the repository (the file stays on disk):

```powershell
git rm --cached procurement.db
```

## Configuration

Put settings in a **`.env`** file in the project folder, one `NAME=value` per line. Start
from `.env.example`. Every way of starting the app reads it: `python app.py`, `flask`, the `.bat`
scripts and the scheduled backup. `.env` is not committed to git because it can hold the
Microsoft client secret. Real environment variables, if set, take precedence.

| Variable | Default | Purpose |
|---|---|---|
| `PROCURETRACK_ENV` | development | `production` on the live server: test sign-in off, HTTPS-only cookies, trusts one reverse proxy (see docs/DEPLOYMENT.md) |
| `PROCURETRACK_DATA_DIR` | `<project>\instance` | Data folder, outside the code folder (here: `C:\ProcureTrack\data`) |
| `PROCURETRACK_OFFSITE_BACKUP_DIR` | not set | Every backup is also copied here (other disk, OneDrive/SharePoint, network share) |
| `PROCURETRACK_HOST` | `127.0.0.1` | `0.0.0.0` to allow other PCs on the office network |
| `PROCURETRACK_PORT` | `5000` | Port |
| `PROCURETRACK_SECRET_KEY` | generated file | Optional: set explicitly instead of the generated file |
| `DATABASE_URL` | SQLite in data folder | Optional: e.g. PostgreSQL later |
| `PROCURETRACK_MS_TENANT_ID` / `_CLIENT_ID` / `_CLIENT_SECRET` | not set | Microsoft 365 sign-in (see above) |
| `PROCURETRACK_MS_REDIRECT_URI` | from the browser address | Only if the automatic callback address is wrong |
| `PROCURETRACK_ADMIN_EMAILS` | not set | Comma-separated emails that become admins when they sign in |
| `PROCURETRACK_TEAM_LEAD_EMAIL` | `vaishnavi.kulkarni@ericrobotics.com` | Recipient of Team Lead notifications and approval requests |
| `PROCURETRACK_TECHNICAL_APPROVER_EMAIL` | not set | Rohit's sign-in email for Engineering requests escalated by the Team Lead |
| `PROCURETRACK_SMTP_HOST` / `_PORT` / `_USERNAME` / `_PASSWORD` / `_FROM` / `_SECURITY` | not set | SMTP for approval notifications; security is `ssl` (465) or `starttls` (587) |

With **Team Lead Approval: No**, ProcureTrack creates the case and emails the Team Lead a
notification only. With **Yes**, it emails a secure review link, and the case is created after
the Team Lead approves. Active Approver users are also notified when a ticket enters the
normal approval stage. See [deployment](docs/DEPLOYMENT.md#smtp-approval-notifications) for
the environment variables. SMTP credentials belong in `.env` or the hosting provider's
secret settings, never in committed source files.

## Backups

- A backup is taken **automatically before every database upgrade**.
- Manual backup: `.\.venv\Scripts\flask --app app backup`
- **Daily backup:** the Windows scheduled task **"ProcureTrack Backup"** runs `scripts\backup.bat`
  at 18:00. If the PC is off then, it runs the next time the PC is on. Check it in
  *Task Scheduler → Task Scheduler Library*. To create it on another machine:

  ```powershell
  $bat = "C:\path\to\PT_V0_3\scripts\backup.bat"
  Register-ScheduledTask -TaskName "ProcureTrack Backup" `
    -Action (New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c `"$bat`"") `
    -Trigger (New-ScheduledTaskTrigger -Daily -At 18:00) `
    -Settings (New-ScheduledTaskSettingsSet -StartWhenAvailable)
  ```

- **Off-site copy:** local backups are on the same disk as the database. Set
  `PROCURETRACK_OFFSITE_BACKUP_DIR` in `.env` to a company OneDrive/SharePoint or network folder,
  and every backup is copied there too (newest 30 kept). If that folder is unavailable,
  the local backup still succeeds and the error is logged.

**Restore:** stop the app, copy the chosen backup over `procurement.db` in the data folder,
start the app.

Use the backup command (not a plain file copy) while the app is running. It uses SQLite's backup
API, which gives a consistent copy even if someone is saving at that moment.

## Developing

See **[docs/DEVELOPER_GUIDE.md](docs/DEVELOPER_GUIDE.md)** for how the code is organised,
the workflow and permission rules, conventions, and step-by-step recipes for common
changes. Planned work is in [docs/ROADMAP.md](docs/ROADMAP.md).

```powershell
.\.venv\Scripts\python -m pip install -r requirements-dev.txt   # adds pytest + ruff
.\.venv\Scripts\python -m pytest                                 # tests
```
